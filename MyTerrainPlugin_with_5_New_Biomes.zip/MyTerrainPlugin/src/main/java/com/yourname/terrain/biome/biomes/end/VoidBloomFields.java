package com.yourname.terrain.biome.biomes.end;
import com.yourname.terrain.biome.BiomeBase; import org.bukkit.ChatColor; import org.bukkit.Sound; import org.bukkit.entity.EntityType; import java.util.List;
public class VoidBloomFields extends BiomeBase { public VoidBloomFields(){ super("void_bloom_fields","Void Bloom Fields","✿",ChatColor.DARK_PURPLE);
climate="Void"; description="Strange flowers bloom from End energy."; rarity="Epic"; difficulty="Very Hard";
enterSound=Sound.ENTITY_ENDERMAN_AMBIENT; nativeMobs=List.of(EntityType.ENDERMAN); structureId="void_garden"; guardianMob="Void Blossom";}
public void generateSurface(int x,int z){} public void generateTrees(int x,int z){} public void generateOres(int x,int z){} public void spawnMobs(int x,int z){} }