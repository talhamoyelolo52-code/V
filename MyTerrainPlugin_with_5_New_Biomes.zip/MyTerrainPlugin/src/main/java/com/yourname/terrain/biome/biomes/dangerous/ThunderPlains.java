package com.yourname.terrain.biome.biomes.dangerous;
import com.yourname.terrain.biome.BiomeBase; import org.bukkit.ChatColor; import org.bukkit.Sound; import org.bukkit.entity.EntityType; import java.util.List;
public class ThunderPlains extends BiomeBase { public ThunderPlains(){ super("thunder_plains","Thunder Plains","⚡",ChatColor.YELLOW);
climate="Stormy"; description="Lightning constantly strikes this biome."; rarity="Rare"; difficulty="Hard";
enterSound=Sound.ENTITY_LIGHTNING_BOLT_THUNDER; nativeMobs=List.of(EntityType.WOLF,EntityType.SKELETON); structureId="storm_tower"; guardianMob="Storm Wolf";}
public void generateSurface(int x,int z){} public void generateTrees(int x,int z){} public void generateOres(int x,int z){} public void spawnMobs(int x,int z){} }