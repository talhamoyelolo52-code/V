package com.yourname.terrain.biome.biomes.dangerous;
import com.yourname.terrain.biome.BiomeBase; import org.bukkit.ChatColor; import org.bukkit.Sound; import org.bukkit.entity.EntityType; import java.util.List;
public class FrostCrystalValley extends BiomeBase { public FrostCrystalValley(){ super("frost_crystal_valley","Frost Crystal Valley","❄",ChatColor.WHITE);
climate="Frozen"; description="Ice crystals cover the landscape."; rarity="Rare"; difficulty="Hard";
enterSound=Sound.BLOCK_GLASS_BREAK; nativeMobs=List.of(EntityType.STRAY,EntityType.POLAR_BEAR); structureId="ice_temple"; guardianMob="Crystal Guardian";}
public void generateSurface(int x,int z){} public void generateTrees(int x,int z){} public void generateOres(int x,int z){} public void spawnMobs(int x,int z){} }