package com.yourname.terrain.biome.biomes.landform;
import com.yourname.terrain.biome.BiomeBase; import org.bukkit.ChatColor; import org.bukkit.Sound; import org.bukkit.entity.EntityType; import java.util.List;
public class AncientRuins extends BiomeBase { public AncientRuins(){ super("ancient_ruins","Ancient Ruins","A",ChatColor.GOLD);
climate="Temperate"; description="Forgotten ruins from a lost civilization."; rarity="Rare"; difficulty="Medium";
enterSound=Sound.BLOCK_CHAIN_PLACE; nativeMobs=List.of(EntityType.ZOMBIE,EntityType.SKELETON); structureId="ruined_temple"; guardianMob="Ancient Sentinel";}
public void generateSurface(int x,int z){} public void generateTrees(int x,int z){} public void generateOres(int x,int z){} public void spawnMobs(int x,int z){} }