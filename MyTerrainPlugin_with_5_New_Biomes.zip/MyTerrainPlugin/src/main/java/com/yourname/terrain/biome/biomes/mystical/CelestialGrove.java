package com.yourname.terrain.biome.biomes.mystical;
import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor; import org.bukkit.Sound; import org.bukkit.entity.EntityType;
import java.util.List;
public class CelestialGrove extends BiomeBase {
public CelestialGrove(){ super("celestial_grove","Celestial Grove","✦",ChatColor.AQUA);
climate="Celestial"; description="A magical grove filled with starlight."; rarity="Rare"; difficulty="Medium";
enterSound=Sound.BLOCK_AMETHYST_BLOCK_CHIME; nativeMobs=List.of(EntityType.ALLAY,EntityType.BEE);
structureId="celestial_shrine"; guardianMob="Star Guardian";}
public void generateSurface(int x,int z){} public void generateTrees(int x,int z){} public void generateOres(int x,int z){} public void spawnMobs(int x,int z){} }