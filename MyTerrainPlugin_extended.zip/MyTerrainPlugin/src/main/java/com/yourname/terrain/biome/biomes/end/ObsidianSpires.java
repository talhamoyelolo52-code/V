package com.yourname.terrain.biome.biomes.end;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class ObsidianSpires extends BiomeBase {

    public ObsidianSpires() {
        super("obsidian_spires", "Obsidian Spires", "\u00a78\u00a7l\u25b2", ChatColor.DARK_GRAY);
        this.climate = "End";
        this.description = "Black obsidian spires reaching into void with crying obsidian";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.ENDERMAN, EntityType.ENDERMITE);
        this.structureId = "obsidian_tower";
        this.guardianMob = "Obsidian Golem";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Obsidian, crying obsidian
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees, obsidian pillars
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra obsidian, netherite
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Obsidian Golem, endermen, endermites
    }
}
