package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class ThunderingPlateau extends BiomeBase {

    public ThunderingPlateau() {
        super("thundering_plateau", "Thundering Plateau", "\u00a7e\u00a7l\u26a1", ChatColor.YELLOW);
        this.climate = "Storm";
        this.description = "Constant thunderstorms, charged creepers, and wind";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.CREEPER, EntityType.PHANTOM, EntityType.WITCH);
        this.structureId = "lightning_rod";
        this.guardianMob = "Storm Caller";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Stone, gravel, no grass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Dead trees, charred
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra redstone, copper
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Storm Caller (Evoker), charged creepers, phantoms
    }
}
