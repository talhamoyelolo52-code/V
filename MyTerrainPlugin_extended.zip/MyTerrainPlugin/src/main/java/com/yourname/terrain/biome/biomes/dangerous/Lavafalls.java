package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class Lavafalls extends BiomeBase {

    public Lavafalls() {
        super("lavafalls", "Lavafalls", "\u00a7c\u00a7l\u25bc", ChatColor.RED);
        this.climate = "Hell";
        this.description = "Waterfalls of lava, obsidian bridges, and fire imps";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.BLAZE, EntityType.MAGMA_CUBE, EntityType.PIGLIN);
        this.structureId = "magma_bridge";
        this.guardianMob = "Lava Serpent";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Lava, obsidian, magma
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees, lava formations
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra netherite, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Lava Serpent (Strider), blazes, magma cubes
    }
}
