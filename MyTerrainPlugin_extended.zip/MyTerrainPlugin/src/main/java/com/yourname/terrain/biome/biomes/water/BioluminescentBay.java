package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class BioluminescentBay extends BiomeBase {

    public BioluminescentBay() {
        super("bioluminescent_bay", "Bioluminescent Bay", "\u00a7b\u00a7l\u2726", ChatColor.AQUA);
        this.climate = "Night Ocean";
        this.description = "Water glows blue at night with plankton particles";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.GLOW_SQUID, EntityType.DOLPHIN, EntityType.TROPICAL_FISH);
        this.structureId = "glow_shrine";
        this.guardianMob = "Jellyfish";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Glowing water, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // Glowing coral
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra glowstone, prismarine
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Jellyfish (Glow Squid), dolphins, tropical fish
    }
}
