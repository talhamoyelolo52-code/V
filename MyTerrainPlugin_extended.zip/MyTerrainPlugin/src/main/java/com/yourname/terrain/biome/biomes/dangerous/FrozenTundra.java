package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class FrozenTundra extends BiomeBase {

    public FrozenTundra() {
        super("frozen_tundra", "Frozen Tundra", "\u00a7b\u00a7l\u2744", ChatColor.AQUA);
        this.climate = "Ice";
        this.description = "Blizzards, aurora, ice spikes, and frozen mobs";
        this.rarity = "Uncommon";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.STRAY, EntityType.POLAR_BEAR, EntityType.SNOW_GOLEM);
        this.structureId = "ice_tower";
        this.guardianMob = "Frost Wraith";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Snow, ice, packed ice
    }

    @Override
    public void generateTrees(int x, int z) {
        // Ice spikes, no trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Frost Wraith, strays, polar bears
    }
}
