package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class TerracedRiceFields extends BiomeBase {

    public TerracedRiceFields() {
        super("terraced_rice_fields", "Terraced Rice Fields", "\u00a72\u00a7l\u25a0", ChatColor.GREEN);
        this.climate = "Asian";
        this.description = "Water-filled terraces with green steps and farmers";
        this.rarity = "Uncommon";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.VILLAGER, EntityType.CHICKEN, EntityType.CAT);
        this.structureId = "farmer_village";
        this.guardianMob = "Rice Farmer";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Terraced water, grass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Small trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Rice Farmer (Villager), chickens, cats
    }
}
