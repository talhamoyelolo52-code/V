package com.yourname.terrain.biome.biomes.end;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class ChorusForest extends BiomeBase {

    public ChorusForest() {
        super("chorus_forest", "Chorus Forest", "\u00a75\u00a7l\u2660", ChatColor.DARK_PURPLE);
        this.climate = "End";
        this.description = "Giant chorus trees with purple fruit and end particles";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.SHULKER, EntityType.ENDERMAN);
        this.structureId = "chorus_spire";
        this.guardianMob = "Chorus Guardian";
    }

    @Override
    public void generateSurface(int x, int z) {
        // End stone, chorus plants
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant chorus trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra chorus, end stone
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Chorus Guardian, shulkers, endermen
    }
}
