package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class VolcanicWasteland extends BiomeBase {

    public VolcanicWasteland() {
        super("volcanic_wasteland", "Volcanic Wasteland", "\u00a7c\u00a7l\u25b2", ChatColor.DARK_RED);
        this.climate = "Hell";
        this.description = "Lava rivers, ash storms, and volcanic vents";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.BLAZE, EntityType.MAGMA_CUBE, EntityType.PIGLIN);
        this.structureId = "lava_forge";
        this.guardianMob = "Blaze Knight";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Basalt, magma blocks, lava
    }

    @Override
    public void generateTrees(int x, int z) {
        // Dead trees, charred
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, netherite
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Blaze Knight, blazes, magma cubes
    }
}
