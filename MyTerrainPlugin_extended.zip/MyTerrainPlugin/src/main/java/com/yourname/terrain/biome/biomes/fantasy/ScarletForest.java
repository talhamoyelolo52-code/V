package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class ScarletForest extends BiomeBase {

    public ScarletForest() {
        super("scarlet_forest", "Scarlet Forest", "\u00a7c\u00a7l\u2764", ChatColor.DARK_RED);
        this.climate = "Warm";
        this.description = "A mystical forest with crimson trees and glowing mushrooms";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.WOLF, EntityType.FOX, EntityType.BAT, EntityType.SPIDER);
        this.structureId = "ruined_altar";
        this.guardianMob = "Forest Guardian";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Crimson grass, podzol, coarse dirt
    }

    @Override
    public void generateTrees(int x, int z) {
        // Custom red trees with crimson leaves, 4-6 blocks tall
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra redstone, rare diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Forest Guardian, wolves, foxes
    }
}
