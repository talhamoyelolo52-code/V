package com.yourname.terrain.biome;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.List;

public abstract class BiomeBase {

    protected String id;
    protected String name;
    protected String icon;
    protected ChatColor color;
    protected String climate;
    protected String description;
    protected String rarity;
    protected String difficulty;
    protected Sound enterSound;
    protected List<EntityType> nativeMobs;
    protected String structureId;
    protected String guardianMob;

    public BiomeBase(String id, String name, String icon, ChatColor color) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.color = color;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getIcon() { return icon; }
    public ChatColor getColor() { return color; }
    public String getClimate() { return climate; }
    public String getDescription() { return description; }
    public String getRarity() { return rarity; }
    public String getDifficulty() { return difficulty; }
    public Sound getEnterSound() { return enterSound; }
    public List<EntityType> getNativeMobs() { return nativeMobs; }
    public String getStructureId() { return structureId; }
    public String getGuardianMob() { return guardianMob; }

    public abstract void generateSurface(int x, int z);
    public abstract void generateTrees(int x, int z);
    public abstract void generateOres(int x, int z);
    public abstract void spawnMobs(int x, int z);
}
