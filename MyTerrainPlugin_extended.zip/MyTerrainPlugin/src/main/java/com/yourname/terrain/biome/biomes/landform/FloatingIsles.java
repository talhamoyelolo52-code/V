package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class FloatingIsles extends BiomeBase {

    public FloatingIsles() {
        super("floating_isles", "Floating Isles", "\u00a7b\u00a7l\u25c6", ChatColor.AQUA);
        this.climate = "Sky";
        this.description = "Islands floating in void with waterfalls falling into void";
        this.rarity = "Very Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.PHANTOM, EntityType.ALLAY, EntityType.PARROT);
        this.structureId = "sky_fortress";
        this.guardianMob = "Sky Pirate";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Floating grass, stone
    }

    @Override
    public void generateTrees(int x, int z) {
        // Floating trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra diamonds, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sky Pirate (Vex), phantoms, allays
    }
}
