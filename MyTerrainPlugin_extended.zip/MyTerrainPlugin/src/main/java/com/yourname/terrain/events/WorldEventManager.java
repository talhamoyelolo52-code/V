package com.yourname.terrain.events;

import com.yourname.terrain.MyTerrainPlugin;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class WorldEventManager {

    private final MyTerrainPlugin plugin;
    private final Random random = new Random();

    private boolean bloodMoonActive = false;
    private boolean meteorShowerActive = false;
    private boolean acidRainActive = false;
    private boolean eclipseActive = false;
    private String currentEvent = null;

    // Night counter for blood moon
    private int nightCount = 0;
    private long lastDayTime = -1;

    public WorldEventManager(MyTerrainPlugin plugin) {
        this.plugin = plugin;
        startEventScheduler();
    }

    private void startEventScheduler() {
        // Check every 30 seconds for event triggers
        new BukkitRunnable() {
            @Override
            public void run() {
                for (World world : Bukkit.getWorlds()) {
                    if (world.getEnvironment() != World.Environment.NORMAL) continue;
                    checkBloodMoon(world);
                    checkMeteorShower(world);
                }
            }
        }.runTaskTimer(plugin, 600L, 600L);

        // Blood moon effect tick
        new BukkitRunnable() {
            @Override
            public void run() {
                if (bloodMoonActive) applyBloodMoonEffects();
                if (acidRainActive) applyAcidRainEffects();
            }
        }.runTaskTimer(plugin, 20L, 40L);
    }

    // ============ BLOOD MOON ============
    private void checkBloodMoon(World world) {
        long time = world.getTime();
        // Night starts at 13000
        if (time >= 13000 && time <= 13100) {
            nightCount++;
            if (nightCount % 7 == 0 && !bloodMoonActive) {
                triggerBloodMoon(world);
            }
        }
        // Dawn - end blood moon
        if (time >= 23000 && bloodMoonActive) {
            endBloodMoon(world);
        }
    }

    public void triggerBloodMoon(World world) {
        bloodMoonActive = true;
        currentEvent = "blood_moon";

        // Set sky red
        world.setStorm(false);
        world.setThundering(false);

        // Announce
        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.DARK_RED + "" + ChatColor.BOLD + "☽ BLOOD MOON ☽",
                ChatColor.RED + "The night awakens with dark power...",
                10, 60, 20
            );
            p.playSound(p.getLocation(), Sound.AMBIENT_CAVE, 1.5f, 0.5f);
            p.sendMessage(plugin.getConfig().getString("general.prefix", "&8[&bPlugin&8]")
                .replace("&", "§") + " §4§l☽ A Blood Moon rises! Mobs are stronger tonight!");
        }

        plugin.getLogger().info("[Event] Blood Moon triggered!");
    }

    private void applyBloodMoonEffects() {
        for (World world : Bukkit.getWorlds()) {
            if (world.getEnvironment() != World.Environment.NORMAL) continue;
            if (world.getTime() < 13000) continue;

            // Buff all hostile mobs
            for (LivingEntity entity : world.getLivingEntities()) {
                if (entity instanceof Monster && entity.getCustomName() == null) {
                    if (!entity.hasPotionEffect(PotionEffectType.STRENGTH)) {
                        entity.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 1));
                        entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 0));
                    }
                }
            }

            // Spawn extra mobs near players
            if (random.nextInt(10) == 0) {
                for (Player p : world.getPlayers()) {
                    Location loc = p.getLocation().clone().add(
                        random.nextInt(30) - 15, 0, random.nextInt(30) - 15
                    );
                    loc.setY(world.getHighestBlockYAt(loc));
                    spawnBloodMoonMob(loc);
                }
            }
        }
    }

    private void spawnBloodMoonMob(Location loc) {
        EntityType[] types = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.CREEPER};
        EntityType type = types[random.nextInt(types.length)];
        LivingEntity mob = (LivingEntity) loc.getWorld().spawnEntity(loc, type);
        mob.setCustomName(ChatColor.DARK_RED + "§4☽ Blood " + capitalize(type.name().toLowerCase()));
        mob.setCustomNameVisible(true);
        mob.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 999999, 2));
        mob.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 999999, 1));
        if (mob.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH) != null) {
            mob.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(40);
            mob.setHealth(40);
        }
    }

    private void endBloodMoon(World world) {
        bloodMoonActive = false;
        currentEvent = null;
        for (Player p : world.getPlayers()) {
            p.sendMessage("§8[§bPlugin§8] §7The Blood Moon fades...");
        }
    }

    // ============ METEOR SHOWER ============
    private void checkMeteorShower(World world) {
        if (!meteorShowerActive && random.nextInt(72000) == 0) {
            triggerMeteorShower(world);
        }
    }

    public void triggerMeteorShower(World world) {
        meteorShowerActive = true;
        currentEvent = "meteor_shower";

        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.GOLD + "" + ChatColor.BOLD + "☄ METEOR SHOWER",
                ChatColor.YELLOW + "The sky rains fire!",
                10, 60, 20
            );
            p.playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 0.7f);
        }

        // Spawn meteors
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (ticks > 200) { // 10 seconds
                    meteorShowerActive = false;
                    currentEvent = null;
                    cancel();
                    return;
                }
                if (ticks % 10 == 0) {
                    for (Player p : world.getPlayers()) {
                        spawnMeteor(p.getLocation(), world);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void spawnMeteor(Location playerLoc, World world) {
        int offsetX = random.nextInt(80) - 40;
        int offsetZ = random.nextInt(80) - 40;
        Location target = playerLoc.clone().add(offsetX, 0, offsetZ);
        target.setY(world.getHighestBlockYAt(target) + 1);

        Location start = target.clone().add(0, 80, 0);

        // Create falling block effect
        org.bukkit.entity.FallingBlock fb = world.spawnFallingBlock(start, Material.MAGMA_BLOCK.createBlockData());
        org.bukkit.util.Vector vel = target.toVector().subtract(start.toVector()).normalize().multiply(3);
        fb.setVelocity(vel);
        fb.setDropItem(false);

        // Schedule impact
        new BukkitRunnable() {
            @Override
            public void run() {
                Location impact = fb.getLocation();
                world.createExplosion(impact, 2.5f, true, false);
                world.spawnParticle(Particle.LAVA, impact, 30, 1, 1, 1, 0.2);
                world.playSound(impact, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f);

                // Rare: drop meteor loot
                if (random.nextInt(5) == 0) {
                    world.dropItemNaturally(impact, new org.bukkit.inventory.ItemStack(Material.NETHERITE_SCRAP));
                }
                if (random.nextInt(20) == 0) {
                    world.dropItemNaturally(impact, new org.bukkit.inventory.ItemStack(Material.NETHERITE_INGOT));
                }
            }
        }.runTaskLater(plugin, 40L);
    }

    // ============ GOBLIN INVASION ============
    public void triggerGoblinInvasion(World world) {
        currentEvent = "goblin_invasion";

        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.GREEN + "" + ChatColor.BOLD + "⚔ GOBLIN INVASION!",
                ChatColor.YELLOW + "Defend your base!",
                10, 80, 20
            );
            p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 2.0f, 1.0f);
            p.sendMessage("§8[§bPlugin§8] §2§l⚔ A Goblin Horde is invading! Survive 3 waves!");
        }

        spawnGoblinWave(world, 1);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (world.getPlayers().isEmpty()) { cancel(); return; }
                spawnGoblinWave(world, 2);
                world.getPlayers().forEach(p -> p.sendMessage("§8[§bPlugin§8] §c§lWave 2! More goblins!"));
            }
        }.runTaskLater(plugin, 600L);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (world.getPlayers().isEmpty()) { cancel(); return; }
                spawnGoblinWave(world, 3);
                world.getPlayers().forEach(p -> p.sendMessage("§8[§bPlugin§8] §4§lFINAL WAVE! Goblin King approaches!"));
                spawnGoblinKing(world);
            }
        }.runTaskLater(plugin, 1200L);

        new BukkitRunnable() {
            @Override
            public void run() {
                currentEvent = null;
                world.getPlayers().forEach(p -> p.sendMessage("§8[§bPlugin§8] §a§l✔ Goblin Invasion repelled! You survived!"));
            }
        }.runTaskLater(plugin, 2400L);
    }

    private void spawnGoblinWave(World world, int wave) {
        int count = wave * 5;
        for (Player p : world.getPlayers()) {
            for (int i = 0; i < count; i++) {
                Location loc = p.getLocation().clone().add(
                    random.nextInt(40) - 20, 0, random.nextInt(40) - 20
                );
                loc.setY(world.getHighestBlockYAt(loc) + 1);
                spawnGoblin(loc, wave);
            }
        }
    }

    private void spawnGoblin(Location loc, int wave) {
        LivingEntity goblin = (LivingEntity) loc.getWorld().spawnEntity(loc, EntityType.PILLAGER);
        goblin.setCustomName(ChatColor.GREEN + "§2Goblin §7[Wave " + wave + "]");
        goblin.setCustomNameVisible(true);
        double hp = 20.0 + (wave * 10);
        goblin.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(hp);
        goblin.setHealth(hp);
        goblin.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 999999, wave - 1));
    }

    private void spawnGoblinKing(World world) {
        for (Player p : world.getPlayers()) {
            Location loc = p.getLocation().clone().add(random.nextInt(20) - 10, 0, random.nextInt(20) - 10);
            loc.setY(world.getHighestBlockYAt(loc) + 1);
            LivingEntity king = (LivingEntity) world.spawnEntity(loc, EntityType.RAVAGER);
            king.setCustomName("§2§lGoblin King §c§l♛");
            king.setCustomNameVisible(true);
            king.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(200);
            king.setHealth(200);
            king.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 999999, 2));
            king.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 999999, 1));
            world.strikeLightningEffect(loc);
            break;
        }
    }

    // ============ EARTHQUAKE ============
    public void triggerEarthquake(World world) {
        currentEvent = "earthquake";

        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.YELLOW + "" + ChatColor.BOLD + "⚡ EARTHQUAKE!",
                ChatColor.GRAY + "The ground shakes beneath you!",
                5, 40, 10
            );
            p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.3f);
        }

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (ticks > 100) {
                    currentEvent = null;
                    cancel();
                    return;
                }
                for (Player p : world.getPlayers()) {
                    // Screen shake via velocity
                    if (ticks % 5 == 0) {
                        p.playSound(p.getLocation(), Sound.BLOCK_STONE_BREAK, 0.5f, 0.5f);
                        p.spawnParticle(Particle.BLOCK, p.getLocation(), 20,
                            1, 0.1, 1, 0.05, Material.DIRT.createBlockData());
                    }
                    // Random block cracking near players
                    if (ticks % 20 == 0 && random.nextBoolean()) {
                        Location crack = p.getLocation().clone().add(
                            random.nextInt(10) - 5, -1, random.nextInt(10) - 5
                        );
                        world.createExplosion(crack, 1.5f, false, false);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ============ ECLIPSE ============
    public void triggerEclipse(World world) {
        eclipseActive = true;
        currentEvent = "eclipse";
        world.setTime(6000); // midday
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);

        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "◉ SOLAR ECLIPSE",
                ChatColor.GRAY + "Darkness falls at noon...",
                10, 80, 20
            );
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                eclipseActive = false;
                currentEvent = null;
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, true);
                world.getPlayers().forEach(p -> p.sendMessage("§8[§bPlugin§8] §7The eclipse passes. Light returns."));
            }
        }.runTaskLater(plugin, 2400L);
    }

    // ============ ACID RAIN ============
    public void triggerAcidRain(World world) {
        acidRainActive = true;
        currentEvent = "acid_rain";
        world.setStorm(true);

        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.GREEN + "" + ChatColor.BOLD + "☁ ACID RAIN",
                ChatColor.DARK_GREEN + "Stay indoors!",
                10, 60, 20
            );
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                acidRainActive = false;
                currentEvent = null;
                world.setStorm(false);
                world.getPlayers().forEach(p -> p.sendMessage("§8[§bPlugin§8] §7The acid rain stops."));
            }
        }.runTaskLater(plugin, 3600L);
    }

    private void applyAcidRainEffects() {
        for (World world : Bukkit.getWorlds()) {
            if (!world.hasStorm()) continue;
            for (Player p : world.getPlayers()) {
                // Only affect players exposed to sky
                if (p.getLocation().getBlock().getLightFromSky() > 10) {
                    if (!p.hasPotionEffect(PotionEffectType.POISON)) {
                        p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 0));
                        p.spawnParticle(Particle.WITCH, p.getLocation().add(0, 2, 0), 5, 0.5, 0.5, 0.5, 0.02);
                    }
                }
            }
        }
    }

    // ============ BLIZZARD ============
    public void triggerBlizzard(World world) {
        currentEvent = "blizzard";
        world.setStorm(true);
        world.setThundering(false);

        for (Player p : world.getPlayers()) {
            p.sendTitle(
                ChatColor.AQUA + "" + ChatColor.BOLD + "❄ BLIZZARD",
                ChatColor.WHITE + "A freezing storm engulfs the land!",
                10, 60, 20
            );
            p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 3600, 1));
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                currentEvent = null;
                world.setStorm(false);
                for (Player p : world.getPlayers()) {
                    p.removePotionEffect(PotionEffectType.SLOWNESS);
                    p.sendMessage("§8[§bPlugin§8] §7The blizzard subsides.");
                }
            }
        }.runTaskLater(plugin, 4800L);
    }

    // Utility
    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).replace("_", " ");
    }

    // Getters
    public boolean isBloodMoonActive() { return bloodMoonActive; }
    public boolean isMeteorShowerActive() { return meteorShowerActive; }
    public boolean isAcidRainActive() { return acidRainActive; }
    public boolean isEclipseActive() { return eclipseActive; }
    public String getCurrentEvent() { return currentEvent; }

    public void shutdown() {
        bloodMoonActive = false;
        meteorShowerActive = false;
        acidRainActive = false;
        eclipseActive = false;
    }
}
