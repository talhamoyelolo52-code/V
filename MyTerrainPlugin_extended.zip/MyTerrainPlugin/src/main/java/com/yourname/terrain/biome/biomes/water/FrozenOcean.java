package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class FrozenOcean extends BiomeBase {

    public FrozenOcean() {
        super("frozen_ocean", "Frozen Ocean", "\u00a7b\u00a7l\u2744", ChatColor.AQUA);
        this.climate = "Ice";
        this.description = "Icebergs, polar bears, seals, and shipwrecks in ice";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.POLAR_BEAR, EntityType.STRAY, EntityType.SALMON);
        this.structureId = "iceberg_cave";
        this.guardianMob = "Polar Bear Alpha";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Ice, packed ice, snow
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Polar Bear Alpha, strays, salmon
    }
}
