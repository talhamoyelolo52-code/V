package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SpireForest extends BiomeBase {

    public SpireForest() {
        super("spire_forest", "Spire Forest", "\u00a78\u00a7l\u25b2", ChatColor.DARK_GRAY);
        this.climate = "Rock";
        this.description = "Tall thin rock spires with bridges between and goats";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.GOAT, EntityType.BAT, EntityType.SKELETON);
        this.structureId = "rock_bridge";
        this.guardianMob = "Mountain Goat";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Stone spires, gravel
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Mountain Goat (Goat), bats, skeletons
    }
}
