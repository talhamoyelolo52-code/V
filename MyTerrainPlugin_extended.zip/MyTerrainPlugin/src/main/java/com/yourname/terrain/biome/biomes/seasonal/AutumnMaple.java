package com.yourname.terrain.biome.biomes.seasonal;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class AutumnMaple extends BiomeBase {

    public AutumnMaple() {
        super("autumn_maple", "Autumn Maple", "\u00a76\u00a7l\u2618", ChatColor.GOLD);
        this.climate = "Autumn";
        this.description = "Red leaves, falling leaves particle, and harvest";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.FOX, EntityType.WOLF, EntityType.RABBIT);
        this.structureId = "harvest_barn";
        this.guardianMob = "Harvest Witch";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Orange grass, fallen leaves
    }

    @Override
    public void generateTrees(int x, int z) {
        // Maple trees with red leaves
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Harvest Witch (Witch), foxes, wolves
    }
}
