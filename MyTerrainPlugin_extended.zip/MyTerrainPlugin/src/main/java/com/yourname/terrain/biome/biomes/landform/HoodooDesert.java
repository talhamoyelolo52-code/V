package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class HoodooDesert extends BiomeBase {

    public HoodooDesert() {
        super("hoodoo_desert", "Hoodoo Desert", "\u00a76\u00a7l\u25b2", ChatColor.GOLD);
        this.climate = "Erosion";
        this.description = "Mushroom-shaped rock formations and slot canyons";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.HUSK, EntityType.SKELETON, EntityType.SPIDER);
        this.structureId = "eroded_temple";
        this.guardianMob = "Sand Spirit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Sand, terracotta, hoodoo rocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, sand
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sand Spirit (Husk), skeletons, spiders
    }
}
