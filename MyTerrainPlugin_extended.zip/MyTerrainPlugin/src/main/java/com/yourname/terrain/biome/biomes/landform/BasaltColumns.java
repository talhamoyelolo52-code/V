package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class BasaltColumns extends BiomeBase {

    public BasaltColumns() {
        super("basalt_columns", "Basalt Columns", "\u00a78\u00a7l\u25a0", ChatColor.DARK_GRAY);
        this.climate = "Volcanic";
        this.description = "Giant's Causeway style hexagonal pillars";
        this.rarity = "Rare";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.MAGMA_CUBE, EntityType.BLAZE, EntityType.SKELETON);
        this.structureId = "giants_forge";
        this.guardianMob = "Giant Smith";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Basalt columns, magma
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Giant Smith (Iron Golem), magma cubes, blazes
    }
}
