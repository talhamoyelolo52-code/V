package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SunkenRuins extends BiomeBase {

    public SunkenRuins() {
        super("sunken_ruins", "Sunken Ruins", "\u00a7b\u00a7l\u2694", ChatColor.AQUA);
        this.climate = "Ocean";
        this.description = "Underwater ancient temples with guardians and treasure";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.GUARDIAN, EntityType.DROWNED, EntityType.ELDER_GUARDIAN);
        this.structureId = "atlantis_gate";
        this.guardianMob = "Guardian";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Prismarine, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra prismarine, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Guardian, drowned, elder guardians
    }
}
