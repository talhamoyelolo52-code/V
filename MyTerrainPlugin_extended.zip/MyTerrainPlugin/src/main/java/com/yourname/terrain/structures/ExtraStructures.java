package com.yourname.terrain.structures;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.Map;

/**
 * Additional structures: Colosseum, Pirate Ship, Wizard Tower, Underground City,
 * Giant Tree Village, Frozen Monastery, Obsidian Pyramid, Crashed Airship,
 * Sunken Galleon, Corrupted Portal, Sky Fortress, Goblin Camp, Bandit Outpost,
 * Cursed Tower, Ancient Temple, Dragon Nest.
 * Called from StructureManager constructor.
 */
public class ExtraStructures {

    public static void register(Map<String, StructureData> structures) {

        structures.put("ancient_temple", new StructureData(
            "Ancient Temple",
            Arrays.asList(Material.CHISELED_STONE_BRICKS, Material.MOSSY_STONE_BRICKS, Material.GOLD_BLOCK),
            Arrays.asList(
                new LootItem(Material.GOLD_INGOT, 5, 12, 0.7),
                new LootItem(Material.DIAMOND, 2, 5, 0.4),
                new LootItem(Material.ENCHANTED_BOOK, 1, 2, 0.3),
                new LootItem(Material.EMERALD, 4, 10, 0.6),
                new LootItem(Material.GOLDEN_APPLE, 1, 2, 0.2)
            ),
            "Ancient Forest Guardian"
        ));

        structures.put("cursed_tower", new StructureData(
            "Cursed Tower",
            Arrays.asList(Material.BLACKSTONE, Material.CRACKED_STONE_BRICKS, Material.SOUL_TORCH),
            Arrays.asList(
                new LootItem(Material.WITHER_SKELETON_SKULL, 1, 2, 0.3),
                new LootItem(Material.NETHERITE_SCRAP, 2, 5, 0.4),
                new LootItem(Material.ENCHANTED_BOOK, 1, 3, 0.4),
                new LootItem(Material.SOUL_LANTERN, 2, 4, 0.6),
                new LootItem(Material.TOTEM_OF_UNDYING, 1, 1, 0.1)
            ),
            "Ancient Lich"
        ));

        structures.put("sky_fortress", new StructureData(
            "Sky Fortress",
            Arrays.asList(Material.QUARTZ_BLOCK, Material.WHITE_CONCRETE, Material.IRON_BLOCK),
            Arrays.asList(
                new LootItem(Material.FEATHER, 10, 20, 0.8),
                new LootItem(Material.DIAMOND, 3, 7, 0.4),
                new LootItem(Material.ELYTRA, 1, 1, 0.15),
                new LootItem(Material.ENCHANTED_BOOK, 1, 2, 0.35),
                new LootItem(Material.GOLDEN_APPLE, 1, 2, 0.25)
            ),
            "Storm Wyvern"
        ));

        structures.put("colosseum", new StructureData(
            "Colosseum",
            Arrays.asList(Material.SMOOTH_SANDSTONE, Material.SANDSTONE, Material.CHISELED_SANDSTONE),
            Arrays.asList(
                new LootItem(Material.IRON_INGOT, 10, 20, 0.8),
                new LootItem(Material.DIAMOND, 2, 5, 0.4),
                new LootItem(Material.GOLDEN_SWORD, 1, 1, 0.3),
                new LootItem(Material.EXPERIENCE_BOTTLE, 10, 20, 0.7),
                new LootItem(Material.ENCHANTED_BOOK, 1, 2, 0.3)
            ),
            "Crystal Colossus"
        ));

        structures.put("pirate_ship", new StructureData(
            "Pirate Ship",
            Arrays.asList(Material.DARK_OAK_PLANKS, Material.OAK_PLANKS, Material.WHITE_WOOL),
            Arrays.asList(
                new LootItem(Material.GOLD_INGOT, 8, 16, 0.7),
                new LootItem(Material.EMERALD, 5, 10, 0.5),
                new LootItem(Material.IRON_SWORD, 1, 1, 0.4),
                new LootItem(Material.TROPICAL_FISH_BUCKET, 1, 3, 0.5),
                new LootItem(Material.MAP, 1, 1, 0.3)
            ),
            "Sea Leviathan"
        ));

        structures.put("wizard_tower", new StructureData(
            "Wizard Tower",
            Arrays.asList(Material.PURPUR_BLOCK, Material.AMETHYST_BLOCK, Material.LECTERN),
            Arrays.asList(
                new LootItem(Material.ENCHANTED_BOOK, 2, 4, 0.6),
                new LootItem(Material.LAPIS_LAZULI, 10, 20, 0.7),
                new LootItem(Material.EXPERIENCE_BOTTLE, 8, 16, 0.7),
                new LootItem(Material.AMETHYST_SHARD, 5, 10, 0.6),
                new LootItem(Material.NETHER_STAR, 1, 1, 0.05)
            ),
            "Mirror God"
        ));

        structures.put("underground_city", new StructureData(
            "Underground City",
            Arrays.asList(Material.STONE_BRICKS, Material.DEEPSLATE_BRICKS, Material.LANTERN),
            Arrays.asList(
                new LootItem(Material.EMERALD, 10, 25, 0.8),
                new LootItem(Material.DIAMOND, 4, 8, 0.5),
                new LootItem(Material.IRON_BLOCK, 5, 10, 0.6),
                new LootItem(Material.ENCHANTED_BOOK, 2, 3, 0.4),
                new LootItem(Material.GOLDEN_APPLE, 2, 4, 0.3)
            ),
            "Ancient Golem King"
        ));

        structures.put("giant_tree_village", new StructureData(
            "Giant Tree Village",
            Arrays.asList(Material.DARK_OAK_LOG, Material.DARK_OAK_LEAVES, Material.STRIPPED_DARK_OAK_LOG),
            Arrays.asList(
                new LootItem(Material.APPLE, 5, 10, 0.8),
                new LootItem(Material.HONEYCOMB, 5, 10, 0.6),
                new LootItem(Material.EMERALD, 4, 8, 0.5),
                new LootItem(Material.ENCHANTED_BOOK, 1, 2, 0.35),
                new LootItem(Material.SADDLE, 1, 1, 0.2)
            ),
            "Forest Guardian"
        ));

        structures.put("frozen_monastery", new StructureData(
            "Frozen Monastery",
            Arrays.asList(Material.PACKED_ICE, Material.SNOW_BLOCK, Material.BLUE_ICE),
            Arrays.asList(
                new LootItem(Material.PRISMARINE_CRYSTALS, 5, 10, 0.6),
                new LootItem(Material.DIAMOND, 3, 6, 0.4),
                new LootItem(Material.ENCHANTED_BOOK, 1, 2, 0.35),
                new LootItem(Material.GOLDEN_APPLE, 1, 2, 0.25),
                new LootItem(Material.ICE, 10, 20, 0.7)
            ),
            "Frost King"
        ));

        structures.put("obsidian_pyramid", new StructureData(
            "Obsidian Pyramid",
            Arrays.asList(Material.OBSIDIAN, Material.CRYING_OBSIDIAN, Material.GOLD_BLOCK),
            Arrays.asList(
                new LootItem(Material.GOLD_BLOCK, 3, 6, 0.5),
                new LootItem(Material.NETHERITE_SCRAP, 3, 6, 0.4),
                new LootItem(Material.DIAMOND, 4, 8, 0.5),
                new LootItem(Material.ENCHANTED_GOLDEN_APPLE, 1, 1, 0.15),
                new LootItem(Material.TNT, 5, 10, 0.6)
            ),
            "Obsidian Titan"
        ));

        structures.put("crashed_airship", new StructureData(
            "Crashed Airship",
            Arrays.asList(Material.IRON_BLOCK, Material.COPPER_BLOCK, Material.OAK_PLANKS),
            Arrays.asList(
                new LootItem(Material.IRON_INGOT, 10, 20, 0.8),
                new LootItem(Material.COPPER_INGOT, 10, 20, 0.7),
                new LootItem(Material.DIAMOND, 3, 6, 0.4),
                new LootItem(Material.ENCHANTED_BOOK, 1, 3, 0.4),
                new LootItem(Material.FIREWORK_ROCKET, 5, 10, 0.5)
            ),
            "Storm Wyvern"
        ));

        structures.put("sunken_galleon", new StructureData(
            "Sunken Galleon",
            Arrays.asList(Material.PRISMARINE_BRICKS, Material.DARK_OAK_PLANKS, Material.SEA_LANTERN),
            Arrays.asList(
                new LootItem(Material.HEART_OF_THE_SEA, 1, 1, 0.2),
                new LootItem(Material.GOLD_INGOT, 8, 16, 0.7),
                new LootItem(Material.PRISMARINE_CRYSTALS, 5, 10, 0.6),
                new LootItem(Material.NAUTILUS_SHELL, 2, 4, 0.5),
                new LootItem(Material.DIAMOND, 3, 6, 0.4)
            ),
            "Sea Emperor"
        ));

        structures.put("corrupted_portal", new StructureData(
            "Corrupted Portal",
            Arrays.asList(Material.CRYING_OBSIDIAN, Material.MAGENTA_STAINED_GLASS, Material.AMETHYST_BLOCK),
            Arrays.asList(
                new LootItem(Material.ECHO_SHARD, 5, 10, 0.6),
                new LootItem(Material.NETHER_STAR, 1, 1, 0.1),
                new LootItem(Material.ENCHANTED_GOLDEN_APPLE, 1, 2, 0.2),
                new LootItem(Material.DIAMOND_BLOCK, 2, 4, 0.3),
                new LootItem(Material.ENDER_PEARL, 10, 20, 0.7)
            ),
            "The Corrupted"
        ));

        structures.put("goblin_camp", new StructureData(
            "Goblin Camp",
            Arrays.asList(Material.MOSSY_COBBLESTONE, Material.OAK_FENCE, Material.CAMPFIRE),
            Arrays.asList(
                new LootItem(Material.IRON_INGOT, 5, 10, 0.7),
                new LootItem(Material.ARROW, 10, 20, 0.8),
                new LootItem(Material.EMERALD, 2, 5, 0.4),
                new LootItem(Material.LEATHER, 5, 10, 0.6),
                new LootItem(Material.BOW, 1, 1, 0.3)
            ),
            "Berserker Brute"
        ));

        structures.put("bandit_outpost", new StructureData(
            "Bandit Outpost",
            Arrays.asList(Material.SPRUCE_PLANKS, Material.COBBLESTONE_WALL, Material.IRON_BARS),
            Arrays.asList(
                new LootItem(Material.GOLD_INGOT, 5, 10, 0.6),
                new LootItem(Material.IRON_SWORD, 1, 1, 0.4),
                new LootItem(Material.EMERALD, 3, 6, 0.5),
                new LootItem(Material.CROSSBOW, 1, 1, 0.3),
                new LootItem(Material.ARROW, 10, 16, 0.7)
            ),
            "Canyon Bandit"
        ));

        structures.put("dragon_nest", new StructureData(
            "Dragon Nest",
            Arrays.asList(Material.NETHER_BRICKS, Material.MAGMA_BLOCK, Material.DRAGON_EGG),
            Arrays.asList(
                new LootItem(Material.DRAGON_BREATH, 5, 10, 0.6),
                new LootItem(Material.NETHERITE_INGOT, 3, 6, 0.4),
                new LootItem(Material.DIAMOND_BLOCK, 2, 4, 0.3),
                new LootItem(Material.ENCHANTED_GOLDEN_APPLE, 1, 2, 0.2),
                new LootItem(Material.ELYTRA, 1, 1, 0.1)
            ),
            "Celestial Dragon"
        ));
    }
}
