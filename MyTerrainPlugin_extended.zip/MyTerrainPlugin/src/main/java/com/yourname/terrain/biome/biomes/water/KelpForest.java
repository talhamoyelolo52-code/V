package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class KelpForest extends BiomeBase {

    public KelpForest() {
        super("kelp_forest", "Kelp Forest", "\u00a72\u00a7l\u25b2", ChatColor.DARK_GREEN);
        this.climate = "Ocean";
        this.description = "Dense kelp 20+ blocks tall with sea turtles";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.TURTLE, EntityType.COD, EntityType.SQUID);
        this.structureId = "sunken_ship";
        this.guardianMob = "Kelp Monster";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Kelp, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant kelp
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Kelp Monster (Drowned), turtles, cod
    }
}
