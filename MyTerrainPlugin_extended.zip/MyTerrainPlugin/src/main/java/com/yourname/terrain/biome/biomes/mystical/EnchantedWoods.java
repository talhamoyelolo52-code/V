package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class EnchantedWoods extends BiomeBase {

    public EnchantedWoods() {
        super("enchanted_woods", "Enchanted Woods", "\u00a7d\u00a7l\u2726", ChatColor.LIGHT_PURPLE);
        this.climate = "Magic";
        this.description = "Floating islands, magic particles, and rare enchanted trees";
        this.rarity = "Rare";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.ALLAY, EntityType.VEX, EntityType.WITCH);
        this.structureId = "wizard_tower";
        this.guardianMob = "Archmage";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Magic grass, floating blocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // Floating trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra lapis, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Archmage (Evoker), allays, vexes
    }
}
