package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class RunestoneHills extends BiomeBase {

    public RunestoneHills() {
        super("runestone_hills", "Runestone Hills", "\u00a78\u00a7l\u25c6", ChatColor.DARK_GRAY);
        this.climate = "Ancient";
        this.description = "Giant rune-carved stones, magic aura, rare enchantments";
        this.rarity = "Rare";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.EVOKER, EntityType.VEX, EntityType.WITCH);
        this.structureId = "rune_circle";
        this.guardianMob = "Rune Master";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Stone, rune blocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra lapis, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Rune Master (Evoker), vexes, witches
    }
}
