package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MirrorLake extends BiomeBase {

    public MirrorLake() {
        super("mirror_lake", "Mirror Lake", "\u00a7b\u00a7l\u25c6", ChatColor.AQUA);
        this.climate = "Calm";
        this.description = "Perfect reflection, swans, and peaceful waters";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.SQUID, EntityType.COD, EntityType.DOLPHIN);
        this.structureId = "reflection_shrine";
        this.guardianMob = "Mirror Spirit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Glass-like water, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Mirror Spirit (Vex), squids, cod
    }
}
