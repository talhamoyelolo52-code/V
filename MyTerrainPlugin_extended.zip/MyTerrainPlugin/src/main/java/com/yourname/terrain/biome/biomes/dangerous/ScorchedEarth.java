package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class ScorchedEarth extends BiomeBase {

    public ScorchedEarth() {
        super("scorched_earth", "Scorched Earth", "\u00a78\u00a7l\u25cf", ChatColor.GRAY);
        this.climate = "Dead";
        this.description = "Cracked earth, dead trees, and rare water sources";
        this.rarity = "Uncommon";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.HUSK, EntityType.SKELETON, EntityType.STRAY);
        this.structureId = "burned_village";
        this.guardianMob = "Ash Zombie";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Cracked dirt, dead grass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Dead trees, no leaves
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Ash Zombie, husks, skeletons
    }
}
