package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class CottonCloudValley extends BiomeBase {

    public CottonCloudValley() {
        super("cotton_cloud_valley", "Cotton Cloud Valley", "\u00a7f\u00a7l\u2601", ChatColor.WHITE);
        this.climate = "Sky";
        this.description = "Ground looks like clouds, no fall damage, soft and fluffy";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.CHICKEN, EntityType.PARROT, EntityType.PHANTOM);
        this.structureId = "cloud_palace";
        this.guardianMob = "Cloud Giant";
    }

    @Override
    public void generateSurface(int x, int z) {
        // White wool blocks, cloud-like
    }

    @Override
    public void generateTrees(int x, int z) {
        // Cloud "trees"
    }

    @Override
    public void generateOres(int x, int z) {
        // Rare diamonds, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Cloud Giant, chickens, parrots
    }
}
