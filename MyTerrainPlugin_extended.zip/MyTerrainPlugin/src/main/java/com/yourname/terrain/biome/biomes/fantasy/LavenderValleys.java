package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class LavenderValleys extends BiomeBase {

    public LavenderValleys() {
        super("lavender_valleys", "Lavender Valleys", "\u00a75\u00a7l\u273f", ChatColor.DARK_PURPLE);
        this.climate = "Flower";
        this.description = "Rolling purple hills with butterflies and sweet scent";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BEE, EntityType.RABBIT, EntityType.BAT);
        this.structureId = "fairy_ring";
        this.guardianMob = "Fairy";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Purple grass, lavender flowers
    }

    @Override
    public void generateTrees(int x, int z) {
        // Rare small oaks
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, lapis
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Fairy (Vex), bees, butterflies
    }
}
