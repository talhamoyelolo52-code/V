package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SunkenCity extends BiomeBase {

    public SunkenCity() {
        super("sunken_city", "Sunken City", "\u00a7b\u00a7l\u2654", ChatColor.AQUA);
        this.climate = "Ruins";
        this.description = "Underwater Atlantis-like ruins with guardians";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.ELDER_GUARDIAN, EntityType.GUARDIAN, EntityType.DROWNED);
        this.structureId = "atlantis_palace";
        this.guardianMob = "Sea Emperor";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Prismarine, gold blocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra diamonds, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sea Emperor (Elder Guardian), guardians, drowned
    }
}
