package com.yourname.terrain.dimensions;

import com.yourname.terrain.MyTerrainPlugin;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public class DimensionManager {

    private final MyTerrainPlugin plugin;
    private final Map<String, CustomDimension> dimensions = new LinkedHashMap<>();
    private final Map<UUID, Location> returnLocations = new HashMap<>();

    public DimensionManager(MyTerrainPlugin plugin) {
        this.plugin = plugin;
        registerDimensions();
    }

    private void registerDimensions() {
        dimensions.put("mirage_realm", new CustomDimension(
            "mirage_realm", "§eMirage Realm", World.Environment.NORMAL,
            "A desert dream-world full of illusions and hidden oases.",
            Material.SAND, Sound.AMBIENT_BASALT_DELTAS_MOOD
        ));

        dimensions.put("fungal_underworld", new CustomDimension(
            "fungal_underworld", "§dFungal Underworld", World.Environment.NORMAL,
            "A subterranean world of giant mushrooms and spore clouds.",
            Material.MYCELIUM, Sound.AMBIENT_CRIMSON_FOREST_MOOD
        ));

        dimensions.put("shattered_sky", new CustomDimension(
            "shattered_sky", "§bShattered Sky", World.Environment.NORMAL,
            "Floating islands with reduced gravity, suspended in an endless sky.",
            Material.STONE, Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD
        ));

        dimensions.put("the_abyss", new CustomDimension(
            "the_abyss", "§8The Abyss", World.Environment.NORMAL,
            "A permanently dark, horror-themed survival challenge.",
            Material.BLACKSTONE, Sound.AMBIENT_WARPED_FOREST_MOOD
        ));

        dimensions.put("volcanic_underworld", new CustomDimension(
            "volcanic_underworld", "§cVolcanic Underworld", World.Environment.NETHER,
            "A molten hellscape beneath the volcanic wasteland.",
            Material.MAGMA_BLOCK, Sound.AMBIENT_NETHER_WASTES_MOOD
        ));

        dimensions.put("mirror_world", new CustomDimension(
            "mirror_world", "§fMirror World", World.Environment.NORMAL,
            "A perfect, eerie reflection of the overworld.",
            Material.GLASS, Sound.BLOCK_GLASS_BREAK
        ));

        plugin.getLogger().info("Registered " + dimensions.size() + " custom dimensions.");
    }

    public void loadDimensions() {
        for (CustomDimension dim : dimensions.values()) {
            if (!isEnabled(dim.id)) continue;
            World world = Bukkit.getWorld(dim.id);
            if (world == null) {
                WorldCreator creator = new WorldCreator(dim.id);
                creator.environment(dim.environment);
                creator.generator(new SimpleDimensionGenerator(dim));
                creator.generateStructures(false);
                world = creator.createWorld();
                if (world != null) {
                    world.setSpawnFlags(false, false);
                    plugin.getLogger().info("Created dimension world: " + dim.id);
                }
            }
        }
    }

    private boolean isEnabled(String key) {
        return plugin.getConfig().getBoolean("dimensions." + key, true);
    }

    public boolean travelTo(Player player, String dimensionId) {
        CustomDimension dim = dimensions.get(dimensionId);
        if (dim == null) return false;

        World world = Bukkit.getWorld(dimensionId);
        if (world == null) {
            player.sendMessage("§8[§bPlugin§8] §cThat dimension is not currently loaded.");
            return false;
        }

        // Save return location
        returnLocations.put(player.getUniqueId(), player.getLocation());

        Location spawn = world.getSpawnLocation().clone();
        spawn.setY(world.getHighestBlockYAt(spawn) + 2);

        player.teleport(spawn);
        player.sendTitle(dim.displayName, "§7" + dim.description, 10, 80, 20);
        player.playSound(player.getLocation(), dim.ambientSound, 1.0f, 1.0f);
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 200, 0));

        applyDimensionEffects(player, dim);

        return true;
    }

    public boolean returnHome(Player player) {
        Location loc = returnLocations.get(player.getUniqueId());
        if (loc == null) {
            World overworld = Bukkit.getWorlds().get(0);
            loc = overworld.getSpawnLocation();
        }
        player.teleport(loc);
        player.sendMessage("§8[§bPlugin§8] §aReturned to your previous location.");
        return true;
    }

    private void applyDimensionEffects(Player player, CustomDimension dim) {
        switch (dim.id) {
            case "shattered_sky" -> {
                // Reduced gravity simulation via slow falling
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 999999, 0, false, false));
                player.sendMessage("§b⬆ Gravity feels lighter here...");
            }
            case "the_abyss" -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 400, 0));
                player.sendMessage("§8☠ Your sanity wavers in this place...");
                startSanityDrain(player);
            }
            case "volcanic_underworld" -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 6000, 0));
                player.sendMessage("§c🔥 The heat is unbearable without protection!");
            }
            case "mirror_world" -> {
                player.sendMessage("§f👁 Everything here looks... reversed.");
            }
            case "mirage_realm" -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 100, 0));
                player.sendMessage("§e〜 The heat haze distorts your vision...");
            }
            case "fungal_underworld" -> {
                player.sendMessage("§d🍄 Spores fill the air around you.");
            }
        }
    }

    private void startSanityDrain(Player player) {
        new org.bukkit.scheduler.BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || !player.getWorld().getName().equals("the_abyss")) {
                    cancel();
                    return;
                }
                ticks++;
                if (ticks % 60 == 0) {
                    // Hallucination effects
                    player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 60, 0));
                    player.playSound(player.getLocation(), Sound.AMBIENT_CAVE, 1.0f, 0.5f);
                    if (Math.random() < 0.3) {
                        player.sendActionBar("§8§o*you hear something behind you*");
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public Collection<CustomDimension> getAllDimensions() {
        return dimensions.values();
    }

    public CustomDimension getDimension(String id) {
        return dimensions.get(id);
    }

    public static class CustomDimension {
        public final String id;
        public final String displayName;
        public final World.Environment environment;
        public final String description;
        public final Material baseBlock;
        public final Sound ambientSound;

        public CustomDimension(String id, String displayName, World.Environment environment,
                                String description, Material baseBlock, Sound ambientSound) {
            this.id = id;
            this.displayName = displayName;
            this.environment = environment;
            this.description = description;
            this.baseBlock = baseBlock;
            this.ambientSound = ambientSound;
        }
    }

    /** Simple chunk generator for custom dimension worlds */
    public static class SimpleDimensionGenerator extends ChunkGenerator {
        private final CustomDimension dimension;

        public SimpleDimensionGenerator(CustomDimension dimension) {
            this.dimension = dimension;
        }

        @Override
        public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
            ChunkData chunkData = createChunkData(world);

            int baseHeight = switch (dimension.id) {
                case "shattered_sky" -> 100; // floating islands - sparse
                case "the_abyss" -> 40;
                default -> 64;
            };

            for (int cx = 0; cx < 16; cx++) {
                for (int cz = 0; cz < 16; cz++) {
                    if (dimension.id.equals("shattered_sky")) {
                        // Floating islands: only generate terrain in patches
                        if (random.nextDouble() < 0.3) {
                            int height = baseHeight + random.nextInt(10);
                            for (int y = height - 5; y < height; y++) {
                                chunkData.setBlock(cx, y, cz, y < height - 1 ? Material.STONE : dimension.baseBlock);
                            }
                        }
                        continue;
                    }

                    int height = baseHeight + random.nextInt(15);
                    for (int y = 0; y < height; y++) {
                        if (y == 0) chunkData.setBlock(cx, y, cz, Material.BEDROCK);
                        else if (y < height - 5) chunkData.setBlock(cx, y, cz, Material.STONE);
                        else if (y < height - 1) chunkData.setBlock(cx, y, cz, Material.DIRT);
                        else chunkData.setBlock(cx, y, cz, dimension.baseBlock);
                    }
                }
            }

            return chunkData;
        }

        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            int y = switch (dimension.id) {
                case "shattered_sky" -> 110;
                default -> 70;
            };
            return new Location(world, 0, y, 0);
        }
    }
}
