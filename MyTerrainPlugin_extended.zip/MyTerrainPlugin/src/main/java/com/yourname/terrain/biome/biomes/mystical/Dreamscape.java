package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class Dreamscape extends BiomeBase {

    public Dreamscape() {
        super("dreamscape", "Dreamscape", "\u00a7d\u00a7l\u2605", ChatColor.LIGHT_PURPLE);
        this.climate = "Surreal";
        this.description = "Floating islands upside down, impossible geometry";
        this.rarity = "Very Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.PHANTOM, EntityType.ALLAY, EntityType.VEX);
        this.structureId = "bed_shrine";
        this.guardianMob = "Dream Eater";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Upside down blocks, floating
    }

    @Override
    public void generateTrees(int x, int z) {
        // Upside down trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, lapis
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Dream Eater (Phantom), allays, vexes
    }
}
