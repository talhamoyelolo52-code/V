package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class Voidlands extends BiomeBase {

    public Voidlands() {
        super("voidlands", "Voidlands", "\u00a78\u00a7l\u25cf", ChatColor.DARK_GRAY);
        this.climate = "End";
        this.description = "Floating islands in void, chorus plants, and endermen";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.ENDERMAN, EntityType.ENDERMITE, EntityType.SHULKER);
        this.structureId = "void_portal";
        this.guardianMob = "Void Walker";
    }

    @Override
    public void generateSurface(int x, int z) {
        // End stone, chorus plants
    }

    @Override
    public void generateTrees(int x, int z) {
        // Chorus "trees"
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra ender pearls, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Void Walker (Enderman), endermites, shulkers
    }
}
