package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class BambooHighlands extends BiomeBase {

    public BambooHighlands() {
        super("bamboo_highlands", "Bamboo Highlands", "\u00a72\u00a7l\u25b2", ChatColor.GREEN);
        this.climate = "Mountain";
        this.description = "Terraced bamboo forests on misty mountain slopes";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.PANDA, EntityType.PARROT, EntityType.OCELOT);
        this.structureId = "pagoda";
        this.guardianMob = "Panda King";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Terraced stone, bamboo grass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant bamboo, 20+ blocks tall
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra emeralds, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Panda King, pandas, parrots
    }
}
