package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class WisteriaFalls extends BiomeBase {

    public WisteriaFalls() {
        super("wisteria_falls", "Wisteria Falls", "\u00a75\u00a7l\u2248", ChatColor.DARK_PURPLE);
        this.climate = "Waterfall";
        this.description = "Purple wisteria vines hanging from cliff waterfalls";
        this.rarity = "Rare";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.BAT, EntityType.CAVE_SPIDER, EntityType.DROWNED);
        this.structureId = "hidden_cave";
        this.guardianMob = "Cave Dweller";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Stone cliffs, water, vines
    }

    @Override
    public void generateTrees(int x, int z) {
        // Wisteria vines hanging
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, lapis
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Cave Dweller, bats, cave spiders
    }
}
