package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class AshenWasteland extends BiomeBase {

    public AshenWasteland() {
        super("ashen_wasteland", "Ashen Wasteland", "\u00a78\u00a7l\u2591", ChatColor.DARK_GRAY);
        this.climate = "Volcanic";
        this.description = "Gray ash ground, dead trees, and volcanic vents";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.BLAZE, EntityType.MAGMA_CUBE, EntityType.WITHER_SKELETON);
        this.structureId = "volcanic_vent";
        this.guardianMob = "Ash Golem";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Ash blocks, blackstone
    }

    @Override
    public void generateTrees(int x, int z) {
        // Charred dead trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, netherite
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Ash Golem (Magma Cube), blazes, wither skeletons
    }
}
