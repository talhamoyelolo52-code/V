package com.yourname.terrain.biome;

import com.yourname.terrain.MyTerrainPlugin;
import com.yourname.terrain.biome.biomes.fantasy.*;
import com.yourname.terrain.biome.biomes.dangerous.*;
import com.yourname.terrain.biome.biomes.water.*;
import com.yourname.terrain.biome.biomes.mystical.*;
import com.yourname.terrain.biome.biomes.landform.*;
import com.yourname.terrain.biome.biomes.seasonal.*;
import com.yourname.terrain.biome.biomes.end.*;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.*;

public class BiomeManager {

    private final MyTerrainPlugin plugin;
    private final Map<String, BiomeBase> biomes = new HashMap<>();
    private final Map<String, BiomeBase> biomeByLocation = new HashMap<>();
    private final List<String> rareBiomes = new ArrayList<>();
    private final List<String> bossBiomes = new ArrayList<>();
    private final Random random = new Random();

    public BiomeManager(MyTerrainPlugin plugin) {
        this.plugin = plugin;
        registerBiomes();
        markRareAndBossBiomes();
    }

    private void registerBiomes() {
        // FANTASY BIOMES (15)
        biomes.put("scarlet_forest", new ScarletForest());
        biomes.put("cherry_fields", new CherryFields());
        biomes.put("muddy_bog", new MuddyBog());
        biomes.put("crystal_caverns", new CrystalCaverns());
        biomes.put("misty_marshlands", new MistyMarshlands());
        biomes.put("sunflower_plains", new SunflowerPlains());
        biomes.put("bamboo_highlands", new BambooHighlands());
        biomes.put("lavender_valleys", new LavenderValleys());
        biomes.put("redwood_forest", new RedwoodForest());
        biomes.put("cherry_blossom_grove", new CherryBlossomGrove());
        biomes.put("autumn_woods", new AutumnWoods());
        biomes.put("wisteria_falls", new WisteriaFalls());
        biomes.put("tea_plantation", new TeaPlantation());
        biomes.put("poppy_fields", new PoppyFields());
        biomes.put("cotton_cloud_valley", new CottonCloudValley());

        // DANGEROUS BIOMES (13)
        biomes.put("volcanic_wasteland", new VolcanicWasteland());
        biomes.put("frozen_tundra", new FrozenTundra());
        biomes.put("thundering_plateau", new ThunderingPlateau());
        biomes.put("toxic_bog", new ToxicBog());
        biomes.put("scorched_earth", new ScorchedEarth());
        biomes.put("ashen_wasteland", new AshenWasteland());
        biomes.put("lavafalls", new Lavafalls());
        biomes.put("sulfur_springs", new SulfurSprings());
        biomes.put("bone_yard", new BoneYard());
        biomes.put("meteor_crater", new MeteorCrater());
        biomes.put("lightning_mesa", new LightningMesa());
        biomes.put("frostburn_tundra", new FrostburnTundra());
        biomes.put("quicksand_desert", new QuicksandDesert());

        // WATER BIOMES (10)
        biomes.put("coral_kingdom", new CoralKingdom());
        biomes.put("kelp_forest", new KelpForest());
        biomes.put("sunken_ruins", new SunkenRuins());
        biomes.put("frozen_ocean", new FrozenOcean());
        biomes.put("bioluminescent_bay", new BioluminescentBay());
        biomes.put("kelp_cathedral", new KelpCathedral());
        biomes.put("sunken_city", new SunkenCity());
        biomes.put("iceberg_alley", new IcebergAlley());
        biomes.put("mangrove_maze", new MangroveMaze());
        biomes.put("mirror_lake", new MirrorLake());

        // MYSTICAL BIOMES (11)
        biomes.put("starlight_meadow", new StarlightMeadow());
        biomes.put("enchanted_woods", new EnchantedWoods());
        biomes.put("voidlands", new Voidlands());
        biomes.put("rainbow_hills", new RainbowHills());
        biomes.put("aurora_valley", new AuroraValley());
        biomes.put("rainbow_bridge", new RainbowBridge());
        biomes.put("timeless_garden", new TimelessGarden());
        biomes.put("mirror_dimension", new MirrorDimension());
        biomes.put("dreamscape", new Dreamscape());
        biomes.put("runestone_hills", new RunestoneHills());
        biomes.put("fae_ring", new FaeRing());

        // LANDFORM BIOMES (11)
        biomes.put("badlands_canyon", new BadlandsCanyon());
        biomes.put("floating_isles", new FloatingIsles());
        biomes.put("giant_mushroom_jungle", new GiantMushroomJungle());
        biomes.put("checkerboard_plains", new CheckerboardPlains());
        biomes.put("spire_forest", new SpireForest());
        biomes.put("terraced_rice_fields", new TerracedRiceFields());
        biomes.put("hoodoo_desert", new HoodooDesert());
        biomes.put("glacial_fjord", new GlacialFjord());
        biomes.put("basalt_columns", new BasaltColumns());
        biomes.put("salt_flats", new SaltFlats());
        biomes.put("dripstone_caverns", new DripstoneCaverns());

        // SEASONAL BIOMES (5)
        biomes.put("spring_meadow", new SpringMeadow());
        biomes.put("summer_beach", new SummerBeach());
        biomes.put("autumn_maple", new AutumnMaple());
        biomes.put("winter_wonderland", new WinterWonderland());
        biomes.put("monsoon_jungle", new MonsoonJungle());

        // END BIOMES (5) - NEW!
        biomes.put("end_wastes", new EndWastes());
        biomes.put("chorus_forest", new ChorusForest());
        biomes.put("obsidian_spires", new ObsidianSpires());
        biomes.put("ender_city_ruins", new EnderCityRuins());
        biomes.put("void_tears", new VoidTears());

        plugin.getLogger().info("Registered " + biomes.size() + " custom biomes!");
    }

    private void markRareAndBossBiomes() {
        // RARE biomes (boss can spawn here)
        rareBiomes.addAll(Arrays.asList(
            "crystal_caverns", "wisteria_falls", "cotton_cloud_valley",
            "volcanic_wasteland", "thundering_plateau", "meteor_crater", 
            "frostburn_tundra", "lavafalls", "sulfur_springs", "bone_yard",
            "sunken_ruins", "sunken_city", "bioluminescent_bay",
            "voidlands", "rainbow_bridge", "mirror_dimension", "dreamscape",
            "floating_isles", "giant_mushroom_jungle", "checkerboard_plains",
            "winter_wonderland", "end_wastes", "chorus_forest", 
            "obsidian_spires", "ender_city_ruins", "void_tears"
        ));

        // BOSS biomes (guaranteed boss in structure)
        bossBiomes.addAll(Arrays.asList(
            "meteor_crater", "frostburn_tundra", "void_tears",
            "obsidian_spires", "ender_city_ruins", "sunken_city",
            "dreamscape", "mirror_dimension", "rainbow_bridge"
        ));
    }

    public boolean isRareBiome(String biomeId) {
        return rareBiomes.contains(biomeId);
    }

    public boolean isBossBiome(String biomeId) {
        return bossBiomes.contains(biomeId);
    }

    public BiomeBase getBiomeAt(Location loc) {
        World world = loc.getWorld();
        int x = loc.getBlockX();
        int z = loc.getBlockZ();

        String key = world.getName() + "_" + (x >> 4) + "_" + (z >> 4);

        if (!biomeByLocation.containsKey(key)) {
            String[] biomeIds = biomes.keySet().toArray(new String[0]);
            String selected = biomeIds[random.nextInt(biomeIds.length)];
            biomeByLocation.put(key, biomes.get(selected));
        }

        return biomeByLocation.get(key);
    }

    public BiomeBase getBiomeById(String id) {
        return biomes.get(id);
    }

    public Map<String, BiomeBase> getAllBiomes() {
        return biomes;
    }

    public List<String> getRareBiomes() {
        return rareBiomes;
    }

    public List<String> getBossBiomes() {
        return bossBiomes;
    }

    public int getBiomeCount() {
        return biomes.size();
    }
}
