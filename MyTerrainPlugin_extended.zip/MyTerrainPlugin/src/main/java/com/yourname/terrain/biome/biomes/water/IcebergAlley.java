package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class IcebergAlley extends BiomeBase {

    public IcebergAlley() {
        super("iceberg_alley", "Iceberg Alley", "\u00a7f\u00a7l\u25c6", ChatColor.WHITE);
        this.climate = "Cold";
        this.description = "Massive icebergs, seals, penguins, and shipwrecks";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.POLAR_BEAR, EntityType.SALMON, EntityType.STRAY);
        this.structureId = "ice_cave";
        this.guardianMob = "Seal";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Icebergs, packed ice
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Seal (Polar Bear), salmon, strays
    }
}
