package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class CrystalCaverns extends BiomeBase {

    public CrystalCaverns() {
        super("crystal_caverns", "Crystal Caverns", "\u00a7b\u00a7l\u25c6", ChatColor.AQUA);
        this.climate = "Underground";
        this.description = "Glowing crystal caves with amethyst formations";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BAT, EntityType.SILVERFISH, EntityType.ENDERMITE);
        this.structureId = "crystal_shrine";
        this.guardianMob = "Crystal Golem";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Amethyst blocks, calcite, budding amethyst
    }

    @Override
    public void generateTrees(int x, int z) {
        // Crystal "trees" - tall amethyst clusters
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra diamonds, amethyst, lapis
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Crystal Golem, silverfish, endermite
    }
}
