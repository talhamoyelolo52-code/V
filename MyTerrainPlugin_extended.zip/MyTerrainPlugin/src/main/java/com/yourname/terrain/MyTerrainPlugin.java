package com.yourname.terrain;

import org.bukkit.plugin.java.JavaPlugin;
import com.yourname.terrain.biome.BiomeManager;
import com.yourname.terrain.listeners.PlayerMoveListener;
import com.yourname.terrain.listeners.ChunkLoadListener;
import com.yourname.terrain.structures.StructureManager;
import com.yourname.terrain.mobs.CustomMobManager;
import com.yourname.terrain.mobs.BossManager;
import com.yourname.terrain.items.FoodManager;
import com.yourname.terrain.commands.BiomeCommand;
import com.yourname.terrain.commands.TerrainCommand;
import com.yourname.terrain.commands.EventCommand;
import com.yourname.terrain.commands.SeasonCommand;
import com.yourname.terrain.commands.RPGCommand;
import com.yourname.terrain.commands.DimensionCommand;
import com.yourname.terrain.events.WorldEventManager;
import com.yourname.terrain.seasons.SeasonManager;
import com.yourname.terrain.rpg.RPGManager;
import com.yourname.terrain.dimensions.DimensionManager;

public class MyTerrainPlugin extends JavaPlugin {

    private static MyTerrainPlugin instance;
    private BiomeManager biomeManager;
    private StructureManager structureManager;
    private CustomMobManager mobManager;
    private BossManager bossManager;
    private FoodManager foodManager;
    private WorldEventManager worldEventManager;
    private SeasonManager seasonManager;
    private RPGManager rpgManager;
    private DimensionManager dimensionManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        biomeManager = new BiomeManager(this);
        structureManager = new StructureManager(this);
        mobManager = new CustomMobManager(this);
        bossManager = new BossManager(this);
        foodManager = new FoodManager();
        worldEventManager = new WorldEventManager(this);
        seasonManager = new SeasonManager(this);
        rpgManager = new RPGManager(this);
        dimensionManager = new DimensionManager(this);

        getServer().getPluginManager().registerEvents(new PlayerMoveListener(this), this);
        getServer().getPluginManager().registerEvents(new ChunkLoadListener(this), this);

        getCommand("biome").setExecutor(new BiomeCommand(this));
        getCommand("terrain").setExecutor(new TerrainCommand(this));

        if (getCommand("event") != null) getCommand("event").setExecutor(new EventCommand(this));
        if (getCommand("season") != null) getCommand("season").setExecutor(new SeasonCommand(this));
        if (getCommand("rpg") != null) getCommand("rpg").setExecutor(new RPGCommand(this));
        if (getCommand("dimension") != null) getCommand("dimension").setExecutor(new DimensionCommand(this));

        getLogger().info("========================================");
        getLogger().info(" MyTerrainPlugin Enabled!");
        getLogger().info(" " + biomeManager.getBiomeCount() + "+ Custom Biomes Loaded!");
        getLogger().info(" " + foodManager.getFoodCount() + " Custom Foods & Fruits!");
        getLogger().info(" " + bossManager.getAllBosses().size() + " Epic Bosses!");
        getLogger().info(" Structures, Loot & Mobs Active!");
        getLogger().info(" World Events, Seasons, RPG & Dimensions Active!");
        getLogger().info("========================================");
    }

    @Override
    public void onDisable() {
        if (seasonManager != null) seasonManager.save();
        if (rpgManager != null) rpgManager.saveAll();
        if (worldEventManager != null) worldEventManager.shutdown();
        getLogger().info("MyTerrainPlugin disabled!");
    }

    public static MyTerrainPlugin getInstance() { return instance; }
    public BiomeManager getBiomeManager() { return biomeManager; }
    public StructureManager getStructureManager() { return structureManager; }
    public CustomMobManager getMobManager() { return mobManager; }
    public BossManager getBossManager() { return bossManager; }
    public FoodManager getFoodManager() { return foodManager; }
    public WorldEventManager getWorldEventManager() { return worldEventManager; }
    public SeasonManager getSeasonManager() { return seasonManager; }
    public RPGManager getRpgManager() { return rpgManager; }
    public DimensionManager getDimensionManager() { return dimensionManager; }
}
