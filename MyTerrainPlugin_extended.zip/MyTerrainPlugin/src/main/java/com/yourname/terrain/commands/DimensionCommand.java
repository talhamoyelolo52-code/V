package com.yourname.terrain.commands;

import com.yourname.terrain.MyTerrainPlugin;
import com.yourname.terrain.dimensions.DimensionManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DimensionCommand implements CommandExecutor {

    private final MyTerrainPlugin plugin;

    public DimensionCommand(MyTerrainPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command!");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.GOLD + "==== Custom Dimensions ====");
            for (DimensionManager.CustomDimension dim : plugin.getDimensionManager().getAllDimensions()) {
                player.sendMessage(dim.displayName + ChatColor.GRAY + " - " + dim.description);
            }
            player.sendMessage(ChatColor.YELLOW + "Use /dimension <name> to travel, /dimension home to return.");
            return true;
        }

        if (args[0].equalsIgnoreCase("home")) {
            plugin.getDimensionManager().returnHome(player);
            return true;
        }

        String key = args[0].toLowerCase().replace(" ", "_");
        boolean success = plugin.getDimensionManager().travelTo(player, key);
        if (!success) {
            player.sendMessage(ChatColor.RED + "Unknown or unloaded dimension: " + args[0]);
        }

        return true;
    }
}
