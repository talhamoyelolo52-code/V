package com.yourname.terrain.rpg;

import java.util.*;

public class PlayerRPGData {

    private final UUID uuid;
    private int reputation = 0;
    private final Set<String> visitedBiomes = new HashSet<>();
    private final Set<String> bossSoulsCollected = new HashSet<>();
    private final Set<String> relicsOwned = new HashSet<>();
    private final Set<String> titlesUnlocked = new HashSet<>();
    private final List<Bounty> activeBounties = new ArrayList<>();
    private String activeProphecy = null;
    private boolean prophecyFulfilled = false;

    public PlayerRPGData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() { return uuid; }

    // Reputation
    public int getReputation() { return reputation; }
    public void addReputation(int amount) { this.reputation += amount; }
    public void setReputation(int rep) { this.reputation = rep; }

    public String getReputationRank() {
        if (reputation >= 1000) return "§6§lLegendary Hero";
        if (reputation >= 500) return "§d§lChampion";
        if (reputation >= 250) return "§b§lRenowned";
        if (reputation >= 100) return "§a§lTrusted";
        if (reputation >= 25) return "§7Recognized";
        return "§8Unknown";
    }

    // Biome Mastery
    public void visitBiome(String biomeId) { visitedBiomes.add(biomeId); }
    public Set<String> getVisitedBiomes() { return visitedBiomes; }
    public int getBiomeCount() { return visitedBiomes.size(); }
    public boolean hasMasteredAll(int totalBiomes) { return visitedBiomes.size() >= totalBiomes; }

    // Boss Souls
    public void collectBossSoul(String bossName) { bossSoulsCollected.add(bossName); }
    public Set<String> getBossSouls() { return bossSoulsCollected; }
    public boolean hasAllBossSouls(int totalBosses) { return bossSoulsCollected.size() >= totalBosses; }

    // Relics
    public void addRelic(String relicId) { relicsOwned.add(relicId); }
    public void removeRelic(String relicId) { relicsOwned.remove(relicId); }
    public Set<String> getRelics() { return relicsOwned; }
    public boolean hasRelic(String relicId) { return relicsOwned.contains(relicId); }

    // Titles
    public void unlockTitle(String title) { titlesUnlocked.add(title); }
    public Set<String> getTitles() { return titlesUnlocked; }
    public boolean hasTitle(String title) { return titlesUnlocked.contains(title); }

    // Bounties
    public List<Bounty> getActiveBounties() { return activeBounties; }
    public void addBounty(Bounty bounty) { activeBounties.add(bounty); }
    public void removeBounty(Bounty bounty) { activeBounties.remove(bounty); }

    // Prophecy
    public String getActiveProphecy() { return activeProphecy; }
    public void setActiveProphecy(String prophecy) { this.activeProphecy = prophecy; this.prophecyFulfilled = false; }
    public boolean isProphecyFulfilled() { return prophecyFulfilled; }
    public void fulfillProphecy() { this.prophecyFulfilled = true; }

    public static class Bounty {
        public final String targetMob;
        public final int amountRequired;
        public int amountKilled;
        public final int rewardReputation;
        public final String rewardItem;

        public Bounty(String targetMob, int amountRequired, int rewardReputation, String rewardItem) {
            this.targetMob = targetMob;
            this.amountRequired = amountRequired;
            this.amountKilled = 0;
            this.rewardReputation = rewardReputation;
            this.rewardItem = rewardItem;
        }

        public boolean isComplete() { return amountKilled >= amountRequired; }
    }
}
