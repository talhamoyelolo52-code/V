package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MistyMarshlands extends BiomeBase {

    public MistyMarshlands() {
        super("misty_marshlands", "Misty Marshlands", "\u00a78\u00a7l\u2592", ChatColor.GRAY);
        this.climate = "Swamp";
        this.description = "Thick fog, mangrove trees, and glowing mushrooms";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.ZOMBIE, EntityType.SLIME, EntityType.WITCH);
        this.structureId = "sunken_shrine";
        this.guardianMob = "Marsh Wraith";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mud, water, fog effect
    }

    @Override
    public void generateTrees(int x, int z) {
        // Cypress trees, Spanish moss
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra clay, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Marsh Wraith, zombies, slimes
    }
}
