package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class QuicksandDesert extends BiomeBase {

    public QuicksandDesert() {
        super("quicksand_desert", "Quicksand Desert", "\u00a76\u00a7l\u25d1", ChatColor.GOLD);
        this.climate = "Trap";
        this.description = "Gold temptations, quicksand sinking, and mirages";
        this.rarity = "Uncommon";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.HUSK, EntityType.SKELETON, EntityType.PILLAGER);
        this.structureId = "sand_trap";
        this.guardianMob = "Desert Bandit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Quicksand blocks, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // Dead cacti
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, sand
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Desert Bandit (Pillager), husks, skeletons
    }
}
