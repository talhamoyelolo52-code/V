package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class RedwoodForest extends BiomeBase {

    public RedwoodForest() {
        super("redwood_forest", "Redwood Forest", "\u00a76\u00a7l\u25b2", ChatColor.GOLD);
        this.climate = "Forest";
        this.description = "Giant 50+ block tall trees with dense canopy";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.WOLF, EntityType.BEAR, EntityType.FOX);
        this.structureId = "treehouse";
        this.guardianMob = "Forest Troll";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Podzol, ferns, moss
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant redwood trees, 50+ blocks
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Forest Troll, wolves, bears
    }
}
