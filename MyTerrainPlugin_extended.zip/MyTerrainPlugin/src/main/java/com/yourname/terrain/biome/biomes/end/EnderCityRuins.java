package com.yourname.terrain.biome.biomes.end;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class EnderCityRuins extends BiomeBase {

    public EnderCityRuins() {
        super("ender_city_ruins", "Ender City Ruins", "\u00a75\u00a7l\u2654", ChatColor.DARK_PURPLE);
        this.climate = "End";
        this.description = "Broken end cities with purpur blocks and end ship wreckage";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.SHULKER, EntityType.ENDERMAN);
        this.structureId = "ruined_city";
        this.guardianMob = "Ender Mage";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Purpur, end stone bricks
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra diamonds, elytra chance
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Ender Mage, shulkers, endermen
    }
}
