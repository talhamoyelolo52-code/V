package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SulfurSprings extends BiomeBase {

    public SulfurSprings() {
        super("sulfur_springs", "Sulfur Springs", "\u00a7e\u00a7l\u2600", ChatColor.YELLOW);
        this.climate = "Toxic";
        this.description = "Yellow sulfur pools, poison gas, and yellow fog";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.CREEPER, EntityType.SLIME, EntityType.WITCH);
        this.structureId = "geyser_field";
        this.guardianMob = "Sulfur Creeper";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Yellow blocks, sulfur
    }

    @Override
    public void generateTrees(int x, int z) {
        // Dead trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gunpowder, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sulfur Creeper (Charged), slimes, witches
    }
}
