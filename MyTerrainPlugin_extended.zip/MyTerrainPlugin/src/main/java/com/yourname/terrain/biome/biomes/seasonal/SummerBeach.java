package com.yourname.terrain.biome.biomes.seasonal;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SummerBeach extends BiomeBase {

    public SummerBeach() {
        super("summer_beach", "Summer Beach", "\u00a7e\u00a7l\u2600", ChatColor.YELLOW);
        this.climate = "Summer";
        this.description = "Palm trees, coconuts, crabs, and surf waves";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.TURTLE, EntityType.DOLPHIN, EntityType.COD);
        this.structureId = "beach_hut";
        this.guardianMob = "Surfer";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Sand, palm trees
    }

    @Override
    public void generateTrees(int x, int z) {
        // Palm trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Surfer (Drowned retextured), turtles, dolphins
    }
}
