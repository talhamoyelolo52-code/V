package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class CherryBlossomGrove extends BiomeBase {

    public CherryBlossomGrove() {
        super("cherry_blossom_grove", "Cherry Blossom Grove", "\u00a7d\u00a7l\u273f", ChatColor.LIGHT_PURPLE);
        this.climate = "Forest";
        this.description = "Pink petals falling, koi ponds, and zen gardens";
        this.rarity = "Uncommon";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BEE, EntityType.RABBIT, EntityType.CAT);
        this.structureId = "torii_gate";
        this.guardianMob = "Sakura Spirit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Pink grass, white sand paths
    }

    @Override
    public void generateTrees(int x, int z) {
        // Cherry blossom trees, falling petals
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, quartz
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sakura Spirit, bees, cats
    }
}
