package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class CoralKingdom extends BiomeBase {

    public CoralKingdom() {
        super("coral_kingdom", "Coral Kingdom", "\u00a7d\u00a7l\u2665", ChatColor.LIGHT_PURPLE);
        this.climate = "Ocean";
        this.description = "Giant coral structures with tropical fish schools";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.TROPICAL_FISH, EntityType.PUFFERFISH, EntityType.DOLPHIN);
        this.structureId = "underwater_palace";
        this.guardianMob = "Sea King";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Coral blocks, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // Coral "trees"
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra prismarine, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sea King (Elder Guardian), tropical fish, dolphins
    }
}
