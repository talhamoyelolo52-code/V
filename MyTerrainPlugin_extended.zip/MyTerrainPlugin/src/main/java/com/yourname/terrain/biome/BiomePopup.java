package com.yourname.terrain.biome;

import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class BiomePopup {

    public void showBiomeEnter(Player player, BiomeBase biome) {
        String title = biome.getColor() + "\u2726 " + biome.getName() + " \u2726";
        String subtitle = "\u00a77" + biome.getIcon() + " " + biome.getClimate() + 
                         " \u00a78| \u00a77" + biome.getRarity();

        player.sendTitle(title, subtitle, 10, 70, 20);

        String actionBar = biome.getColor() + "\u2554\u2550\u2550 " + biome.getName() + " \u2550\u2550\u2557\n" +
                          "\u00a77" + biome.getDescription() + "\n" +
                          biome.getColor() + "\u255a\u2550\u2550 \u00a7c" + biome.getDifficulty() + 
                          " \u00a78| \u00a7e" + biome.getStructureId() + " \u2550\u2550\u255d";

        player.sendActionBar(actionBar);

        player.playSound(player.getLocation(), biome.getEnterSound(), 1.0f, 1.0f);

        player.spawnParticle(Particle.END_ROD, player.getLocation(), 50, 2, 2, 2, 0.1);
    }

    public void showBiomeExit(Player player, BiomeBase biome) {
        player.sendTitle("\u00a77Leaving " + biome.getName(), "", 10, 30, 10);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.5f, 0.5f);
    }
}
