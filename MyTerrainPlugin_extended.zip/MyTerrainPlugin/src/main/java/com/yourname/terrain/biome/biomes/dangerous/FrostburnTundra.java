package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class FrostburnTundra extends BiomeBase {

    public FrostburnTundra() {
        super("frostburn_tundra", "Frostburn Tundra", "\u00a7b\u00a7l\u26a1", ChatColor.AQUA);
        this.climate = "Mixed";
        this.description = "Half ice half fire, steam where they meet, rare";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BLAZE, EntityType.STRAY, EntityType.MAGMA_CUBE);
        this.structureId = "steam_vent";
        this.guardianMob = "Elemental";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Half ice, half magma
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra diamonds, netherite
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Elemental (Blaze + Stray), blazes, strays
    }
}
