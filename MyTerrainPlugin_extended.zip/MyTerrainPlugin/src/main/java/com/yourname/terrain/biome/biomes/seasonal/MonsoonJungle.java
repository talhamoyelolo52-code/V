package com.yourname.terrain.biome.biomes.seasonal;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MonsoonJungle extends BiomeBase {

    public MonsoonJungle() {
        super("monsoon_jungle", "Monsoon Jungle", "\u00a72\u00a7l\u2618", ChatColor.DARK_GREEN);
        this.climate = "Rain";
        this.description = "Constant rain, flooded ground, lush green, and mud";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.OCELOT, EntityType.PARROT, EntityType.PANDA);
        this.structureId = "tree_canopy_village";
        this.guardianMob = "Jungle Chief";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Jungle grass, mud, water
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant jungle trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, emeralds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Jungle Chief (Pillager), ocelots, parrots
    }
}
