package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class CheckerboardPlains extends BiomeBase {

    public CheckerboardPlains() {
        super("checkerboard_plains", "Checkerboard Plains", "\u00a7f\u00a7l\u25a0", ChatColor.WHITE);
        this.climate = "Weird";
        this.description = "Alternating colored grass blocks creating optical illusion";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.SHEEP, EntityType.RABBIT, EntityType.CHICKEN);
        this.structureId = "illusion_temple";
        this.guardianMob = "Illusionist";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Checkerboard grass pattern
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra emeralds, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Illusionist (Illusioner), sheep, rabbits
    }
}
