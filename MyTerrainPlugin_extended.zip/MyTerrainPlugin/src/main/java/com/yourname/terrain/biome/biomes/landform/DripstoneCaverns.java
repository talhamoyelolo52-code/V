package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class DripstoneCaverns extends BiomeBase {

    public DripstoneCaverns() {
        super("dripstone_caverns", "Dripstone Caverns", "\u00a78\u00a7l\u25bc", ChatColor.DARK_GRAY);
        this.climate = "Underground";
        this.description = "Massive stalactites and stalagmites with underground rivers";
        this.rarity = "Uncommon";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BAT, EntityType.CAVE_SPIDER, EntityType.DROWNED);
        this.structureId = "stalactite_city";
        this.guardianMob = "Cave King";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Dripstone, water
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, redstone, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Cave King (Warden mini), bats, cave spiders
    }
}
