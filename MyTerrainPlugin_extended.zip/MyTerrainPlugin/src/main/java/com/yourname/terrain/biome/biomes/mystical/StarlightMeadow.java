package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class StarlightMeadow extends BiomeBase {

    public StarlightMeadow() {
        super("starlight_meadow", "Starlight Meadow", "\u00a7e\u00a7l\u2605", ChatColor.YELLOW);
        this.climate = "Night";
        this.description = "Glows at night, fireflies, shooting stars, moon flowers";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.ALLAY, EntityType.BAT, EntityType.RABBIT);
        this.structureId = "observatory";
        this.guardianMob = "Star Watcher";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Glowing grass, star flowers
    }

    @Override
    public void generateTrees(int x, int z) {
        // Glowing trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra glowstone, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Star Watcher (Wandering Trader), allays, bats
    }
}
