package com.yourname.terrain.biome.biomes.end;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class VoidTears extends BiomeBase {

    public VoidTears() {
        super("void_tears", "Void Tears", "\u00a78\u00a7l\u25bc", ChatColor.DARK_GRAY);
        this.climate = "End";
        this.description = "Holes to void with floating islands and dragon breath particles";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.ENDER_DRAGON, EntityType.ENDERMAN);
        this.structureId = "tear_shrine";
        this.guardianMob = "Void Leviathan";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Floating islands, void gaps
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Dragon breath, end crystals
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Void Leviathan (Ender Dragon mini), endermen
    }
}
