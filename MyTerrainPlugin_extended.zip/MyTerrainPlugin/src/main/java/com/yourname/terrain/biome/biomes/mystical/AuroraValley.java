package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class AuroraValley extends BiomeBase {

    public AuroraValley() {
        super("aurora_valley", "Aurora Valley", "\u00a7b\u00a7l\u2605", ChatColor.AQUA);
        this.climate = "Night";
        this.description = "Aurora borealis in sky, ice crystals, and peaceful";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.STRAY, EntityType.POLAR_BEAR, EntityType.RABBIT);
        this.structureId = "ice_observatory";
        this.guardianMob = "Aurora Spirit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Ice, snow, aurora particles
    }

    @Override
    public void generateTrees(int x, int z) {
        // Ice trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra ice, diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Aurora Spirit (Stray glowing), polar bears, rabbits
    }
}
