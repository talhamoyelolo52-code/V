package com.yourname.terrain.seasons;

import com.yourname.terrain.MyTerrainPlugin;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;

public class SeasonManager {

    public enum Season {
        SPRING("Spring", "§a", "🌸", "Rains often, mobs are peaceful, plants grow fast."),
        SUMMER("Summer", "§e", "☀", "Hot and dry, more hostile mobs, fruit grows."),
        AUTUMN("Autumn", "§6", "🍂", "Harvest time, balanced mobs, colorful terrain."),
        WINTER("Winter", "§b", "❄", "Cold and dark, mobs are stronger, snow falls.");

        public final String name;
        public final String color;
        public final String icon;
        public final String description;

        Season(String name, String color, String icon, String description) {
            this.name = name;
            this.color = color;
            this.icon = icon;
            this.description = description;
        }
    }

    private final MyTerrainPlugin plugin;
    private Season currentSeason = Season.SPRING;
    private int dayInSeason = 0;
    private final int DAYS_PER_SEASON = 7; // real MC days
    private File dataFile;
    private FileConfiguration data;

    public SeasonManager(MyTerrainPlugin plugin) {
        this.plugin = plugin;
        dataFile = new File(plugin.getDataFolder(), "seasons.yml");
        load();
        startSeasonCycle();
    }

    public void load() {
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
        String savedSeason = data.getString("current-season", "SPRING");
        dayInSeason = data.getInt("day-in-season", 0);
        try {
            currentSeason = Season.valueOf(savedSeason);
        } catch (Exception e) {
            currentSeason = Season.SPRING;
        }
        plugin.getLogger().info("Loaded season: " + currentSeason.name + " (Day " + dayInSeason + ")");
    }

    public void save() {
        data.set("current-season", currentSeason.name());
        data.set("day-in-season", dayInSeason);
        try { data.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }

    private void startSeasonCycle() {
        // Check for day change every 10 minutes
        new BukkitRunnable() {
            long lastTime = -1;
            @Override
            public void run() {
                for (World world : Bukkit.getWorlds()) {
                    if (world.getEnvironment() != World.Environment.NORMAL) continue;
                    long time = world.getTime();
                    // Detect new day (time resets to ~0)
                    if (lastTime > 20000 && time < 1000) {
                        advanceDay(world);
                    }
                    lastTime = time;
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);

        // Apply season effects every 30 seconds
        new BukkitRunnable() {
            @Override
            public void run() {
                applySeasonEffects();
            }
        }.runTaskTimer(plugin, 600L, 600L);
    }

    private void advanceDay(World world) {
        dayInSeason++;
        if (dayInSeason >= DAYS_PER_SEASON) {
            dayInSeason = 0;
            Season nextSeason = getNextSeason();
            transitionSeason(world, nextSeason);
        }
        save();
    }

    private Season getNextSeason() {
        return switch (currentSeason) {
            case SPRING -> Season.SUMMER;
            case SUMMER -> Season.AUTUMN;
            case AUTUMN -> Season.WINTER;
            case WINTER -> Season.SPRING;
        };
    }

    private void transitionSeason(World world, Season newSeason) {
        Season oldSeason = currentSeason;
        currentSeason = newSeason;

        // Announce
        for (Player p : world.getPlayers()) {
            p.sendTitle(
                newSeason.color + "" + ChatColor.BOLD + newSeason.icon + " " + newSeason.name + " begins!",
                ChatColor.GRAY + newSeason.description,
                10, 100, 30
            );
            p.playSound(p.getLocation(), getSeasonSound(newSeason), 1.0f, 1.0f);
            p.sendMessage("§8[§bPlugin§8] " + newSeason.color + "§l" + newSeason.icon + " Season changed: " + newSeason.name + "!");
        }

        // Apply season-specific world changes
        applySeasonWorldChange(world, newSeason, oldSeason);
        plugin.getLogger().info("Season changed: " + oldSeason.name + " -> " + newSeason.name);
    }

    private void applySeasonWorldChange(World world, Season newSeason, Season old) {
        switch (newSeason) {
            case WINTER -> {
                world.setStorm(true);
                world.setThundering(false);
            }
            case SPRING -> {
                // Random light rain
                if (Math.random() < 0.5) world.setStorm(true);
                else world.setStorm(false);
            }
            case SUMMER -> {
                world.setStorm(false);
                world.setThundering(false);
            }
            case AUTUMN -> {
                world.setStorm(false);
            }
        }
    }

    private void applySeasonEffects() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            switch (currentSeason) {
                case WINTER -> {
                    // Cold damage outside if no warm armor
                    if (!isWarmEnough(p) && p.getLocation().getBlock().getLightFromSky() > 5) {
                        if (Math.random() < 0.1) {
                            p.damage(0.5);
                            p.sendActionBar("§b❄ You're freezing!");
                        }
                    }
                }
                case SUMMER -> {
                    // Heat exhaustion in deserts
                    String biomeKey = p.getLocation().getBlock().getBiome().name();
                    if (biomeKey.contains("DESERT") || biomeKey.contains("BADLANDS")) {
                        if (Math.random() < 0.05) {
                            p.setFoodLevel(Math.max(0, p.getFoodLevel() - 1));
                            p.sendActionBar("§6☀ The heat drains you...");
                        }
                    }
                }
                case SPRING -> {
                    // Small regen boost
                    if (p.getHealth() < p.getMaxHealth() && Math.random() < 0.05) {
                        p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + 0.5));
                    }
                }
                case AUTUMN -> {
                    // Slight hunger reduction (harvest time = abundant food)
                    if (p.getFoodLevel() < 20 && Math.random() < 0.05) {
                        p.setFoodLevel(Math.min(20, p.getFoodLevel() + 1));
                    }
                }
            }
        }
    }

    private boolean isWarmEnough(Player p) {
        if (p.getInventory().getHelmet() != null) {
            String name = p.getInventory().getHelmet().getType().name();
            if (name.contains("LEATHER") || name.contains("GOLD") || name.contains("DIAMOND") || name.contains("NETHERITE")) return true;
        }
        return false;
    }

    private Sound getSeasonSound(Season s) {
        return switch (s) {
            case SPRING -> Sound.AMBIENT_CAVE;
            case SUMMER -> Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
            case AUTUMN -> Sound.BLOCK_CHERRY_LEAVES_BREAK;
            case WINTER -> Sound.WEATHER_RAIN;
        };
    }

    public Season getCurrentSeason() { return currentSeason; }
    public int getDayInSeason() { return dayInSeason; }
    public int getDaysPerSeason() { return DAYS_PER_SEASON; }
    public int getDaysRemaining() { return DAYS_PER_SEASON - dayInSeason; }

    // Admin force
    public void forceSetSeason(Season season, World world) {
        Season old = currentSeason;
        currentSeason = season;
        dayInSeason = 0;
        applySeasonWorldChange(world, season, old);
        save();
        for (Player p : world.getPlayers()) {
            p.sendTitle(
                season.color + "" + ChatColor.BOLD + season.icon + " " + season.name + "!",
                "§7Season was changed by an admin.",
                10, 60, 20
            );
        }
    }
}
