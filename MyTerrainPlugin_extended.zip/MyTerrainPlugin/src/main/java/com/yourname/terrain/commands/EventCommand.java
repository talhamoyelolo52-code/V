package com.yourname.terrain.commands;

import com.yourname.terrain.MyTerrainPlugin;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EventCommand implements CommandExecutor {

    private final MyTerrainPlugin plugin;

    public EventCommand(MyTerrainPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("terrain.admin") && !sender.isOp()) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(ChatColor.GOLD + "==== World Events ====");
            sender.sendMessage(ChatColor.YELLOW + "/event bloodmoon" + ChatColor.GRAY + " - Trigger a Blood Moon");
            sender.sendMessage(ChatColor.YELLOW + "/event meteorshower" + ChatColor.GRAY + " - Trigger a Meteor Shower");
            sender.sendMessage(ChatColor.YELLOW + "/event goblininvasion" + ChatColor.GRAY + " - Start a Goblin Invasion");
            sender.sendMessage(ChatColor.YELLOW + "/event earthquake" + ChatColor.GRAY + " - Trigger an Earthquake");
            sender.sendMessage(ChatColor.YELLOW + "/event eclipse" + ChatColor.GRAY + " - Trigger a Solar Eclipse");
            sender.sendMessage(ChatColor.YELLOW + "/event acidrain" + ChatColor.GRAY + " - Trigger Acid Rain");
            sender.sendMessage(ChatColor.YELLOW + "/event blizzard" + ChatColor.GRAY + " - Trigger a Blizzard");
            sender.sendMessage(ChatColor.YELLOW + "/event status" + ChatColor.GRAY + " - Show active events");
            return true;
        }

        World world;
        if (sender instanceof Player) {
            world = ((Player) sender).getWorld();
        } else {
            world = plugin.getServer().getWorlds().get(0);
        }

        switch (args[0].toLowerCase()) {
            case "bloodmoon" -> {
                plugin.getWorldEventManager().triggerBloodMoon(world);
                sender.sendMessage(ChatColor.RED + "Blood Moon triggered!");
            }
            case "meteorshower" -> {
                plugin.getWorldEventManager().triggerMeteorShower(world);
                sender.sendMessage(ChatColor.GOLD + "Meteor Shower triggered!");
            }
            case "goblininvasion" -> {
                plugin.getWorldEventManager().triggerGoblinInvasion(world);
                sender.sendMessage(ChatColor.GREEN + "Goblin Invasion started!");
            }
            case "earthquake" -> {
                plugin.getWorldEventManager().triggerEarthquake(world);
                sender.sendMessage(ChatColor.YELLOW + "Earthquake triggered!");
            }
            case "eclipse" -> {
                plugin.getWorldEventManager().triggerEclipse(world);
                sender.sendMessage(ChatColor.DARK_GRAY + "Solar Eclipse triggered!");
            }
            case "acidrain" -> {
                plugin.getWorldEventManager().triggerAcidRain(world);
                sender.sendMessage(ChatColor.GREEN + "Acid Rain triggered!");
            }
            case "blizzard" -> {
                plugin.getWorldEventManager().triggerBlizzard(world);
                sender.sendMessage(ChatColor.AQUA + "Blizzard triggered!");
            }
            case "status" -> {
                String current = plugin.getWorldEventManager().getCurrentEvent();
                sender.sendMessage(ChatColor.GOLD + "Current event: " + ChatColor.WHITE
                    + (current == null ? "None" : current));
            }
            default -> sender.sendMessage(ChatColor.RED + "Unknown event. Use /event for a list.");
        }

        return true;
    }
}
