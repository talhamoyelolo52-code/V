package com.yourname.terrain.biome.biomes.end;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class EndWastes extends BiomeBase {

    public EndWastes() {
        super("end_wastes", "End Wastes", "\u00a78\u00a7l\u25cf", ChatColor.DARK_GRAY);
        this.climate = "End";
        this.description = "Barren End islands floating in void with purple particles";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.ENDERMAN, EntityType.ENDERMITE);
        this.structureId = "end_ruins";
        this.guardianMob = "Ender Knight";
    }

    @Override
    public void generateSurface(int x, int z) {
        // End stone, void gaps
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees, chorus patches
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra end stone, chorus
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Ender Knight, endermen, endermites
    }
}
