package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class KelpCathedral extends BiomeBase {

    public KelpCathedral() {
        super("kelp_cathedral", "Kelp Cathedral", "\u00a72\u00a7l\u25c6", ChatColor.DARK_GREEN);
        this.climate = "Underwater";
        this.description = "Giant kelp forming tunnels with light rays";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_UNDERWATER_LOOP_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.TURTLE, EntityType.COD, EntityType.SQUID);
        this.structureId = "underwater_temple";
        this.guardianMob = "Sea Priest";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Kelp tunnels, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // Kelp "cathedral" arches
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, gold
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Sea Priest (Drowned), turtles, cod
    }
}
