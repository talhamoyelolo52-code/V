package com.yourname.terrain.biome.biomes.seasonal;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SpringMeadow extends BiomeBase {

    public SpringMeadow() {
        super("spring_meadow", "Spring Meadow", "\u00a7a\u00a7l\u273f", ChatColor.GREEN);
        this.climate = "Spring";
        this.description = "New growth, baby animals, butterflies, and Easter feel";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.RABBIT, EntityType.BEE, EntityType.CHICKEN);
        this.structureId = "flower_garden";
        this.guardianMob = "Spring Spirit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Fresh grass, flowers
    }

    @Override
    public void generateTrees(int x, int z) {
        // Fresh leaf trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Spring Spirit (Allay), rabbits, bees
    }
}
