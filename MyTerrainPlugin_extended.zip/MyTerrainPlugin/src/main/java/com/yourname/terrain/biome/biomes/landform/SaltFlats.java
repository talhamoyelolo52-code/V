package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SaltFlats extends BiomeBase {

    public SaltFlats() {
        super("salt_flats", "Salt Flats", "\u00a7f\u00a7l\u25a0", ChatColor.WHITE);
        this.climate = "Dry";
        this.description = "White flat ground with mirror reflections when wet";
        this.rarity = "Uncommon";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.ZOMBIE_VILLAGER, EntityType.SKELETON, EntityType.HUSK);
        this.structureId = "salt_mine";
        this.guardianMob = "Salt Miner";
    }

    @Override
    public void generateSurface(int x, int z) {
        // White blocks, salt
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Salt Miner (Zombie Villager), skeletons, husks
    }
}
