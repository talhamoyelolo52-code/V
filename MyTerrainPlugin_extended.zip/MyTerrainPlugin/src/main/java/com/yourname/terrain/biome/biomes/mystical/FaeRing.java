package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class FaeRing extends BiomeBase {

    public FaeRing() {
        super("fae_ring", "Fae Ring", "\u00a7d\u00a7l\u2726", ChatColor.LIGHT_PURPLE);
        this.climate = "Fairy";
        this.description = "Mushroom circles, tiny houses, and mischievous fairies";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.ALLAY, EntityType.VEX, EntityType.RABBIT);
        this.structureId = "mushroom_circle";
        this.guardianMob = "Fairy Queen";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mushroom blocks, mycelium
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant mushrooms
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, emeralds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Fairy Queen (Vex), allays, rabbits
    }
}
