package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class ToxicBog extends BiomeBase {

    public ToxicBog() {
        super("toxic_bog", "Toxic Bog", "\u00a72\u00a7l\u2620", ChatColor.DARK_GREEN);
        this.climate = "Poison";
        this.description = "Green toxic water, poison gas, and mutated plants";
        this.rarity = "Uncommon";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.SLIME, EntityType.WITCH, EntityType.ZOMBIE);
        this.structureId = "poison_pit";
        this.guardianMob = "Toxic Slime";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Green toxic blocks, mud
    }

    @Override
    public void generateTrees(int x, int z) {
        // Dead, twisted trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, sulfur
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Toxic Slime (Giant Slime), witches, zombies
    }
}
