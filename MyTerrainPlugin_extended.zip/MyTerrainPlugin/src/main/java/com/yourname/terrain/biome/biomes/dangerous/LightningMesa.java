package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class LightningMesa extends BiomeBase {

    public LightningMesa() {
        super("lightning_mesa", "Lightning Mesa", "\u00a76\u00a7l\u26a1", ChatColor.GOLD);
        this.climate = "Storm";
        this.description = "Flat top mountains, constant lightning, charged sand";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.CREEPER, EntityType.PHANTOM, EntityType.WITCH);
        this.structureId = "tesla_coil";
        this.guardianMob = "Electric Eel";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mesa clay, red sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra copper, redstone
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Electric Eel (Guardian), charged creepers, phantoms
    }
}
