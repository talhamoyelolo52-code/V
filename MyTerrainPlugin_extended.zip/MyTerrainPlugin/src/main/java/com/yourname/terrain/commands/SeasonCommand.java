package com.yourname.terrain.commands;

import com.yourname.terrain.MyTerrainPlugin;
import com.yourname.terrain.seasons.SeasonManager;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SeasonCommand implements CommandExecutor {

    private final MyTerrainPlugin plugin;

    public SeasonCommand(MyTerrainPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        SeasonManager sm = plugin.getSeasonManager();

        if (args.length == 0) {
            SeasonManager.Season season = sm.getCurrentSeason();
            sender.sendMessage(ChatColor.GOLD + "==== Current Season ====");
            sender.sendMessage(season.color + "" + ChatColor.BOLD + season.icon + " " + season.name);
            sender.sendMessage(ChatColor.GRAY + season.description);
            sender.sendMessage(ChatColor.YELLOW + "Day " + sm.getDayInSeason() + "/" + sm.getDaysPerSeason()
                + ChatColor.GRAY + " (" + sm.getDaysRemaining() + " days until next season)");
            return true;
        }

        if (!sender.hasPermission("terrain.admin") && !sender.isOp()) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to set the season.");
            return true;
        }

        World world;
        if (sender instanceof Player) world = ((Player) sender).getWorld();
        else world = plugin.getServer().getWorlds().get(0);

        try {
            SeasonManager.Season season = SeasonManager.Season.valueOf(args[0].toUpperCase());
            sm.forceSetSeason(season, world);
            sender.sendMessage(ChatColor.GREEN + "Season set to " + season.name + "!");
        } catch (IllegalArgumentException e) {
            sender.sendMessage(ChatColor.RED + "Invalid season. Use: SPRING, SUMMER, AUTUMN, WINTER");
        }

        return true;
    }
}
