package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MuddyBog extends BiomeBase {

    public MuddyBog() {
        super("muddy_bog", "Muddy Bog", "\u00a72\u00a7l\u2248", ChatColor.DARK_GREEN);
        this.climate = "Swamp";
        this.description = "Thick mud, quicksand patches, and glowing fireflies";
        this.rarity = "Common";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.SLIME, EntityType.FROG, EntityType.WITCH);
        this.structureId = "witch_hut";
        this.guardianMob = "Swamp Witch";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mud blocks, podzol, water patches
    }

    @Override
    public void generateTrees(int x, int z) {
        // Mangrove-style trees, dead oak
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra clay, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Swamp Witch, slimes, frogs
    }
}
