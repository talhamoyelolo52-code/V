package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class GlacialFjord extends BiomeBase {

    public GlacialFjord() {
        super("glacial_fjord", "Glacial Fjord", "\u00a7b\u00a7l\u25bc", ChatColor.AQUA);
        this.climate = "Ice";
        this.description = "Deep water between steep cliffs with waterfalls and cold";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.POLAR_BEAR, EntityType.SALMON, EntityType.STRAY);
        this.structureId = "viking_longhouse";
        this.guardianMob = "Viking";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Ice, water, stone cliffs
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra iron, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Viking (Pillager), polar bears, salmon
    }
}
