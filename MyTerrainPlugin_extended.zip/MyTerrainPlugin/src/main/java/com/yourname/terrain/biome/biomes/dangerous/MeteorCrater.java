package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MeteorCrater extends BiomeBase {

    public MeteorCrater() {
        super("meteor_crater", "Meteor Crater", "\u00a75\u00a7l\u2605", ChatColor.DARK_PURPLE);
        this.climate = "Impact";
        this.description = "Giant crater, meteorite ore, and alien plants";
        this.rarity = "Very Rare";
        this.difficulty = "Very Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.ENDERMAN, EntityType.ENDERMITE, EntityType.SHULKER);
        this.structureId = "alien_pod";
        this.guardianMob = "Space Invader";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Crater shape, meteorite blocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // Alien crystal formations
    }

    @Override
    public void generateOres(int x, int z) {
        // Meteorite ore (glowing), diamonds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Space Invader (Enderman), endermites, shulkers
    }
}
