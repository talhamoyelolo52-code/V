package com.yourname.terrain.rpg;

import com.yourname.terrain.MyTerrainPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class RPGManager {

    private final MyTerrainPlugin plugin;
    private final Map<UUID, PlayerRPGData> playerData = new HashMap<>();
    private final List<String> prophecies = new ArrayList<>();
    private final Random random = new Random();
    private File dataFile;

    public RPGManager(MyTerrainPlugin plugin) {
        this.plugin = plugin;
        dataFile = new File(plugin.getDataFolder(), "rpgdata.yml");
        registerProphecies();
        loadAll();
    }

    private void registerProphecies() {
        prophecies.add("Defeat the Void Leviathan to claim the Soul of Darkness");
        prophecies.add("Visit 25 unique biomes to become a True Explorer");
        prophecies.add("Collect souls from 5 different bosses");
        prophecies.add("Survive a full Blood Moon without dying");
        prophecies.add("Discover the Mirror Dimension and defeat the Mirror God");
        prophecies.add("Tame a Cherry Spirit and bring it to the Crystal Caverns");
        prophecies.add("Find the legendary Dragon Fruit in the End Wastes");
        prophecies.add("Survive an entire Meteor Shower in the open");
    }

    public PlayerRPGData getData(Player player) {
        return playerData.computeIfAbsent(player.getUniqueId(), PlayerRPGData::new);
    }

    // ============ REPUTATION SYSTEM ============
    public void addReputation(Player player, int amount, String reason) {
        PlayerRPGData data = getData(player);
        int oldRank = getRankIndex(data.getReputation());
        data.addReputation(amount);
        int newRank = getRankIndex(data.getReputation());

        player.sendActionBar("§a+" + amount + " Reputation §7(" + reason + ")");

        if (newRank > oldRank) {
            player.sendTitle("§6§lRANK UP!", data.getReputationRank(), 10, 60, 20);
            player.sendMessage("§8[§bPlugin§8] §6You are now " + data.getReputationRank() + "§7!");
        }
    }

    private int getRankIndex(int rep) {
        if (rep >= 1000) return 5;
        if (rep >= 500) return 4;
        if (rep >= 250) return 3;
        if (rep >= 100) return 2;
        if (rep >= 25) return 1;
        return 0;
    }

    // ============ BIOME MASTERY ============
    public void onBiomeVisit(Player player, String biomeId) {
        PlayerRPGData data = getData(player);
        boolean isNew = !data.getVisitedBiomes().contains(biomeId);
        if (isNew) {
            data.visitBiome(biomeId);
            player.sendMessage("§8[§bPlugin§8] §b📖 New biome discovered: §f" + formatBiomeName(biomeId)
                + " §7(" + data.getBiomeCount() + " total)");
            addReputation(player, 2, "Discovery");

            int total = plugin.getBiomeManager().getAllBiomes().size();
            if (data.hasMasteredAll(total) && !data.hasTitle("Biome Master")) {
                data.unlockTitle("Biome Master");
                player.sendTitle("§d§l⭐ BIOME MASTER", "§7You've explored every biome!", 10, 100, 30);
                addReputation(player, 100, "Biome Mastery");
                giveRelic(player, "explorers_compass");
            }
        }
    }

    private String formatBiomeName(String id) {
        String[] parts = id.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    // ============ BOSS SOUL COLLECTION ============
    public void onBossKilled(Player player, String bossName) {
        PlayerRPGData data = getData(player);
        boolean isNew = !data.getBossSouls().contains(bossName);
        if (isNew) {
            data.collectBossSoul(bossName);
            player.sendMessage("§8[§bPlugin§8] §5👻 Boss Soul captured: §d" + bossName);
            addReputation(player, 25, "Boss Slayer");

            // Give soul item
            ItemStack soul = new ItemStack(Material.NETHER_STAR);
            ItemMeta meta = soul.getItemMeta();
            meta.setDisplayName("§5§l" + bossName + " Soul");
            meta.setLore(Arrays.asList("§7A captured essence of", "§7the defeated " + bossName + ".",
                "§8Used in the Soul Forge."));
            soul.setItemMeta(meta);
            player.getInventory().addItem(soul);

            int totalBosses = plugin.getBossManager().getAllBosses().size();
            if (data.hasAllBossSouls(totalBosses) && !data.hasTitle("Soul Reaper")) {
                data.unlockTitle("Soul Reaper");
                player.sendTitle("§4§l☠ SOUL REAPER", "§7You've collected every boss soul!", 10, 100, 30);
                addReputation(player, 200, "Soul Reaper");
                unlockSecretDimensionAccess(player);
            }
        }
    }

    private void unlockSecretDimensionAccess(Player player) {
        player.sendMessage("§8[§bPlugin§8] §4§l✦ A rift to a secret dimension has opened for you! ✦");
        // This would integrate with DimensionManager
    }

    // ============ RELIC SYSTEM ============
    public void giveRelic(Player player, String relicId) {
        PlayerRPGData data = getData(player);
        if (data.hasRelic(relicId)) {
            player.sendMessage("§8[§bPlugin§8] §7You already own this relic.");
            return;
        }
        data.addRelic(relicId);
        ItemStack relic = createRelicItem(relicId);
        player.getInventory().addItem(relic);
        player.sendMessage("§8[§bPlugin§8] §6✦ Relic obtained: §e" + getRelicName(relicId));
    }

    public ItemStack createRelicItem(String relicId) {
        ItemStack item;
        ItemMeta meta;
        switch (relicId) {
            case "explorers_compass" -> {
                item = new ItemStack(Material.COMPASS);
                meta = item.getItemMeta();
                meta.setDisplayName("§d§lExplorer's Compass");
                meta.setLore(Arrays.asList("§7Always points toward",
                    "§7the nearest undiscovered biome.",
                    "§8Relic - Biome Mastery Reward"));
            }
            case "phoenix_feather" -> {
                item = new ItemStack(Material.FEATHER);
                meta = item.getItemMeta();
                meta.setDisplayName("§6§lPhoenix Feather");
                meta.setLore(Arrays.asList("§7Grants fire resistance",
                    "§7and slow falling when held.",
                    "§8Relic - Volcanic Wasteland Reward"));
            }
            case "void_shard" -> {
                item = new ItemStack(Material.ECHO_SHARD);
                meta = item.getItemMeta();
                meta.setDisplayName("§8§lVoid Shard");
                meta.setLore(Arrays.asList("§7Pulses with dark energy.",
                    "§7Reduces fall damage by 50%.",
                    "§8Relic - Void Tears Reward"));
            }
            case "frost_core" -> {
                item = new ItemStack(Material.PRISMARINE_CRYSTALS);
                meta = item.getItemMeta();
                meta.setDisplayName("§b§lFrost Core");
                meta.setLore(Arrays.asList("§7Radiates intense cold.",
                    "§7Immune to freezing damage.",
                    "§8Relic - Frostburn Tundra Reward"));
            }
            default -> {
                item = new ItemStack(Material.NETHER_STAR);
                meta = item.getItemMeta();
                meta.setDisplayName("§f§lUnknown Relic");
            }
        }
        item.setItemMeta(meta);
        return item;
    }

    private String getRelicName(String relicId) {
        return switch (relicId) {
            case "explorers_compass" -> "Explorer's Compass";
            case "phoenix_feather" -> "Phoenix Feather";
            case "void_shard" -> "Void Shard";
            case "frost_core" -> "Frost Core";
            default -> "Unknown Relic";
        };
    }

    // ============ BOUNTY BOARD ============
    public PlayerRPGData.Bounty generateBounty(Player player) {
        String[] mobs = {"Forest Troll", "Crystal Golem", "Ash Zombie", "Sand Spirit",
            "Frost Wraith", "Storm Caller", "Canyon Bandit", "Kelp Monster"};
        String mob = mobs[random.nextInt(mobs.length)];
        int amount = 3 + random.nextInt(8);
        int reward = amount * 10;
        PlayerRPGData.Bounty bounty = new PlayerRPGData.Bounty(mob, amount, reward, "experience_bottle");
        getData(player).addBounty(bounty);
        player.sendMessage("§8[§bPlugin§8] §e📜 New Bounty: §fKill " + amount + "x §c" + mob
            + " §7for §a" + reward + " reputation");
        return bounty;
    }

    public void onMobKilled(Player player, String mobName) {
        PlayerRPGData data = getData(player);
        Iterator<PlayerRPGData.Bounty> it = data.getActiveBounties().iterator();
        while (it.hasNext()) {
            PlayerRPGData.Bounty bounty = it.next();
            if (bounty.targetMob.equals(mobName)) {
                bounty.amountKilled++;
                player.sendActionBar("§e📜 Bounty: " + bounty.amountKilled + "/" + bounty.amountRequired
                    + " " + mobName);
                if (bounty.isComplete()) {
                    addReputation(player, bounty.rewardReputation, "Bounty Complete");
                    player.getInventory().addItem(new ItemStack(Material.EXPERIENCE_BOTTLE, 5));
                    player.sendMessage("§8[§bPlugin§8] §a✔ Bounty completed! §7+"
                        + bounty.rewardReputation + " reputation");
                    it.remove();
                }
            }
        }
    }

    // ============ PROPHECY SYSTEM ============
    public void assignProphecy(Player player) {
        PlayerRPGData data = getData(player);
        if (data.getActiveProphecy() != null) {
            player.sendMessage("§8[§bPlugin§8] §7Your prophecy: §f" + data.getActiveProphecy());
            return;
        }
        String prophecy = prophecies.get(random.nextInt(prophecies.size()));
        data.setActiveProphecy(prophecy);
        player.sendTitle("§5§l✦ PROPHECY ✦", "§7" + prophecy, 10, 100, 30);
        player.sendMessage("§8[§bPlugin§8] §5✦ A prophecy has been foretold: §f" + prophecy);
    }

    public void checkProphecyFulfillment(Player player) {
        PlayerRPGData data = getData(player);
        String prophecy = data.getActiveProphecy();
        if (prophecy == null || data.isProphecyFulfilled()) return;

        boolean fulfilled = false;
        if (prophecy.contains("Void Leviathan") && data.getBossSouls().contains("Void Leviathan")) fulfilled = true;
        if (prophecy.contains("25 unique biomes") && data.getBiomeCount() >= 25) fulfilled = true;
        if (prophecy.contains("5 different bosses") && data.getBossSouls().size() >= 5) fulfilled = true;
        if (prophecy.contains("Mirror God") && data.getBossSouls().contains("Mirror God")) fulfilled = true;

        if (fulfilled) {
            data.fulfillProphecy();
            player.sendTitle("§6§l✦ PROPHECY FULFILLED ✦", "§7" + prophecy, 10, 100, 30);
            player.sendMessage("§8[§bPlugin§8] §6§l✦ Your prophecy has been fulfilled! ✦");
            addReputation(player, 150, "Prophecy Fulfilled");
            giveRelic(player, "phoenix_feather");
            data.setActiveProphecy(null);
        }
    }

    // ============ ACHIEVEMENT TITLES ============
    public void checkAndUnlockTitles(Player player) {
        PlayerRPGData data = getData(player);

        if (data.getBossSouls().contains("Void Leviathan") && !data.hasTitle("Void Walker")) {
            data.unlockTitle("Void Walker");
            announceTitle(player, "Void Walker");
        }
        if (data.getBossSouls().contains("Frost King") && !data.hasTitle("Frostbane")) {
            data.unlockTitle("Frostbane");
            announceTitle(player, "Frostbane");
        }
        if (data.getBossSouls().contains("Sea Emperor") && !data.hasTitle("Tidecaller")) {
            data.unlockTitle("Tidecaller");
            announceTitle(player, "Tidecaller");
        }
        if (data.getBiomeCount() >= 10 && !data.hasTitle("Wanderer")) {
            data.unlockTitle("Wanderer");
            announceTitle(player, "Wanderer");
        }
        if (data.getReputation() >= 500 && !data.hasTitle("Champion")) {
            data.unlockTitle("Champion");
            announceTitle(player, "Champion");
        }
    }

    private void announceTitle(Player player, String title) {
        player.sendTitle("§e§l⭐ TITLE UNLOCKED", "§f" + title, 10, 80, 20);
        player.sendMessage("§8[§bPlugin§8] §e⭐ New title unlocked: §f\"" + title + "\"");
    }

    // ============ PERSISTENCE ============
    public void loadAll() {
        if (!dataFile.exists()) return;
        FileConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String uuidStr : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                PlayerRPGData data = new PlayerRPGData(uuid);
                data.setReputation(config.getInt(uuidStr + ".reputation", 0));
                for (String b : config.getStringList(uuidStr + ".biomes")) data.visitBiome(b);
                for (String b : config.getStringList(uuidStr + ".souls")) data.collectBossSoul(b);
                for (String r : config.getStringList(uuidStr + ".relics")) data.addRelic(r);
                for (String t : config.getStringList(uuidStr + ".titles")) data.unlockTitle(t);
                playerData.put(uuid, data);
            } catch (Exception ignored) {}
        }
    }

    public void saveAll() {
        FileConfiguration config = new YamlConfiguration();
        for (Map.Entry<UUID, PlayerRPGData> entry : playerData.entrySet()) {
            String key = entry.getKey().toString();
            PlayerRPGData data = entry.getValue();
            config.set(key + ".reputation", data.getReputation());
            config.set(key + ".biomes", new ArrayList<>(data.getVisitedBiomes()));
            config.set(key + ".souls", new ArrayList<>(data.getBossSouls()));
            config.set(key + ".relics", new ArrayList<>(data.getRelics()));
            config.set(key + ".titles", new ArrayList<>(data.getTitles()));
        }
        try { config.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }
}
