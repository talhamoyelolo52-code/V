package com.yourname.terrain.biome.biomes.water;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MangroveMaze extends BiomeBase {

    public MangroveMaze() {
        super("mangrove_maze", "Mangrove Maze", "\u00a72\u00a7l\u25c6", ChatColor.DARK_GREEN);
        this.climate = "Swamp Water";
        this.description = "Dense mangrove roots forming tunnels with crocodiles";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.DROWNED, EntityType.SLIME, EntityType.WITCH);
        this.structureId = "root_tunnel";
        this.guardianMob = "Crocodile";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mangrove roots, water
    }

    @Override
    public void generateTrees(int x, int z) {
        // Mangrove trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra clay, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Crocodile (Drowned), slimes, witches
    }
}
