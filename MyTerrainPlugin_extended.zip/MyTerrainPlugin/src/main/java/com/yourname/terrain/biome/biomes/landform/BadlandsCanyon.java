package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class BadlandsCanyon extends BiomeBase {

    public BadlandsCanyon() {
        super("badlands_canyon", "Badlands Canyon", "\u00a76\u00a7l\u25bc", ChatColor.GOLD);
        this.climate = "Desert";
        this.description = "Deep red canyons with layered rock and exposed gold veins";
        this.rarity = "Uncommon";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.HUSK, EntityType.SKELETON, EntityType.PILLAGER);
        this.structureId = "cliff_dwelling";
        this.guardianMob = "Canyon Bandit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Red sand, terracotta, gold
    }

    @Override
    public void generateTrees(int x, int z) {
        // No trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, terracotta
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Canyon Bandit (Pillager), husks, skeletons
    }
}
