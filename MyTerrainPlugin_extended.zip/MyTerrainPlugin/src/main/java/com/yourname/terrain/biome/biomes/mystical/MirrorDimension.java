package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class MirrorDimension extends BiomeBase {

    public MirrorDimension() {
        super("mirror_dimension", "Mirror Dimension", "\u00a7f\u00a7l\u25c6", ChatColor.WHITE);
        this.climate = "Weird";
        this.description = "Everything mirrored, reverse gravity water, confusing";
        this.rarity = "Very Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.VEX, EntityType.ENDERMAN, EntityType.PHANTOM);
        this.structureId = "reflection_maze";
        this.guardianMob = "Doppelganger";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mirror blocks, glass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Mirror trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra diamonds, emeralds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Doppelganger (Player clone), vexes, endermen
    }
}
