package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class AutumnWoods extends BiomeBase {

    public AutumnWoods() {
        super("autumn_woods", "Autumn Woods", "\u00a76\u00a7l\u2618", ChatColor.GOLD);
        this.climate = "Forest";
        this.description = "Orange and red leaves, fallen leaf carpet, squirrels";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.FOX, EntityType.WOLF, EntityType.RABBIT);
        this.structureId = "abandoned_cabin";
        this.guardianMob = "Woodcutter";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Orange grass, fallen leaves
    }

    @Override
    public void generateTrees(int x, int z) {
        // Oak trees with orange/red leaves
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Woodcutter (Zombie), foxes, wolves
    }
}
