package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class TeaPlantation extends BiomeBase {

    public TeaPlantation() {
        super("tea_plantation", "Tea Plantation", "\u00a72\u00a7l\u2618", ChatColor.DARK_GREEN);
        this.climate = "Hills";
        this.description = "Terraced green tea fields with misty mornings";
        this.rarity = "Uncommon";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.VILLAGER, EntityType.CAT, EntityType.CHICKEN);
        this.structureId = "tea_house";
        this.guardianMob = "Tea Master";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Terraced hills, green grass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Small tea bushes
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Tea Master (Villager), cats, chickens
    }
}
