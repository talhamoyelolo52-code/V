package com.yourname.terrain.items;

import org.bukkit.Material;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;

/**
 * Additional fruit tree foods, herbs and mushroom variants.
 * Called from FoodManager constructor.
 */
public class ExtraFoods {

    public static void register(Map<String, FoodItem> foods) {

        // ============ MANGO TREE ============
        foods.put("mango", new FoodItem(
            "mango",
            "\u00a76Mango",
            Material.SWEET_BERRIES,
            5, 3.0,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SATURATION, 60, 0)
            },
            "\u00a77A juicy mango from the Forgotten Orchard"
        ));

        // ============ COCONUT PALM ============
        foods.put("coconut", new FoodItem(
            "coconut",
            "\u00a7fCoconut",
            Material.COCOA_BEANS,
            4, 4.0,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.WATER_BREATHING, 200, 0)
            },
            "\u00a77Refreshing coconut from a tropical palm"
        ));

        // ============ DRAGONFRUIT VINE ============
        foods.put("dragonfruit_vine", new FoodItem(
            "dragonfruit_vine",
            "\u00a7dDragonfruit (Vine)",
            Material.PITCHER_PLANT,
            6, 4.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.NIGHT_VISION, 300, 0),
                new PotionEffect(PotionEffectType.SPEED, 200, 0)
            },
            "\u00a77A vibrant fruit grown on jungle vines"
        ));

        // ============ GLOWBERRY BUSH (Custom) ============
        foods.put("glowberry_custom", new FoodItem(
            "glowberry_custom",
            "\u00a7eGlowing Berry",
            Material.GLOW_BERRIES,
            4, 3.2,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.GLOWING, 200, 0),
                new PotionEffect(PotionEffectType.NIGHT_VISION, 200, 0)
            },
            "\u00a77These berries glow faintly even after picking"
        ));

        // ============ CRYSTAL APPLE TREE ============
        foods.put("crystal_apple", new FoodItem(
            "crystal_apple",
            "\u00a7bCrystal Apple",
            Material.APPLE,
            6, 5.0,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.RESISTANCE, 300, 0),
                new PotionEffect(PotionEffectType.GLOWING, 100, 0)
            },
            "\u00a77A translucent apple infused with crystal energy"
        ));

        // ============ STARFRUIT TREE ============
        foods.put("starfruit", new FoodItem(
            "starfruit",
            "\u00a7eStarfruit",
            Material.GLISTERING_MELON_SLICE,
            5, 4.0,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.LUCK, 600, 0),
                new PotionEffect(PotionEffectType.NIGHT_VISION, 300, 0)
            },
            "\u00a77A star-shaped fruit said to bring good fortune"
        ));

        // ============ CACAO TREE (Chocolate crafting base) ============
        foods.put("cacao_pod", new FoodItem(
            "cacao_pod",
            "\u00a76Cacao Pod",
            Material.COCOA_BEANS,
            2, 1.0,
            new PotionEffect[]{},
            "\u00a77Raw cacao - can be crafted into chocolate"
        ));

        foods.put("chocolate_bar", new FoodItem(
            "chocolate_bar",
            "\u00a76\u00a7lChocolate Bar",
            Material.COOKIE,
            6, 5.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SATURATION, 200, 1)
            },
            "\u00a77Rich chocolate crafted from cacao pods"
        ));

        // ============ PAPAYA ============
        foods.put("papaya", new FoodItem(
            "papaya",
            "\u00a76Papaya",
            Material.SWEET_BERRIES,
            5, 3.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 100, 0),
                new PotionEffect(PotionEffectType.SATURATION, 60, 0)
            },
            "\u00a77A sweet tropical papaya"
        ));

        // ============ LYCHEE BUSH ============
        foods.put("lychee", new FoodItem(
            "lychee",
            "\u00a7dLychee",
            Material.SWEET_BERRIES,
            3, 2.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 80, 0)
            },
            "\u00a77A fragrant lychee with a sweet floral taste"
        ));

        // ============ MUSHROOM VARIANTS ============
        foods.put("healing_shroom", new FoodItem(
            "healing_shroom",
            "\u00a7aHealing Shroom",
            Material.RED_MUSHROOM,
            3, 2.0,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 300, 1),
                new PotionEffect(PotionEffectType.HEALTH_BOOST, 600, 0)
            },
            "\u00a77A mushroom with potent healing properties"
        ));

        foods.put("poison_shroom", new FoodItem(
            "poison_shroom",
            "\u00a72Poison Shroom",
            Material.BROWN_MUSHROOM,
            1, 0.2,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.POISON, 200, 1)
            },
            "\u00a77WARNING: Toxic mushroom - do not eat raw!"
        ));

        foods.put("glow_shroom", new FoodItem(
            "glow_shroom",
            "\u00a7bGlow Shroom",
            Material.GLOW_LICHEN,
            3, 2.2,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.GLOWING, 400, 0),
                new PotionEffect(PotionEffectType.NIGHT_VISION, 400, 0)
            },
            "\u00a77A bioluminescent fungus from Glowstone Grotto"
        ));

        // ============ WILD BERRY BUSH ============
        foods.put("wild_berry", new FoodItem(
            "wild_berry",
            "\u00a7cWild Berry",
            Material.SWEET_BERRIES,
            2, 1.5,
            new PotionEffect[]{},
            "\u00a77A common berry found scattered in forests"
        ));

        // ============ GIANT PUMPKIN ============
        foods.put("giant_pumpkin_slice", new FoodItem(
            "giant_pumpkin_slice",
            "\u00a76Giant Pumpkin Slice",
            Material.PUMPKIN_PIE,
            7, 6.0,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SATURATION, 300, 1)
            },
            "\u00a77A slice from a massive seasonal pumpkin"
        ));

        // ============ HERB SYSTEM (combine = potions without brewing) ============
        foods.put("medicinal_herb", new FoodItem(
            "medicinal_herb",
            "\u00a7aMedicinal Herb",
            Material.FERN,
            1, 0.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 100, 0)
            },
            "\u00a77Combine herbs together to brew effects without a stand"
        ));

        foods.put("frost_herb", new FoodItem(
            "frost_herb",
            "\u00a7bFrost Herb",
            Material.AZURE_BLUET,
            1, 0.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.RESISTANCE, 100, 0)
            },
            "\u00a77A cold-resistant herb found in tundra biomes"
        ));

        foods.put("ember_herb", new FoodItem(
            "ember_herb",
            "\u00a7cEmber Herb",
            Material.WITHER_ROSE,
            1, 0.5,
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 0)
            },
            "\u00a77A warm herb that grows near volcanic vents"
        ));
    }
}
