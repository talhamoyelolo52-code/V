package com.yourname.terrain.mobs;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;

/**
 * Registers additional bosses (Tier 2/3, RPG bosses, event bosses) on top of
 * the original BossManager set. Called from BossManager constructor.
 */
public class ExtraBosses {

    public static void register(Map<String, BossData> bosses) {

        // ============ FOREST GUARDIAN (Tier 1) ============
        bosses.put("Ancient Forest Guardian", new BossData(
            EntityType.RAVAGER,
            "\u00a72\u00a7l\u2618 Ancient Forest Guardian \u00a72\u00a7l\u2618",
            220.0, 22.0, true,
            new ItemStack[]{ new ItemStack(Material.IRON_AXE) },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 1),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 1)
            },
            new String[]{"Root Slam", "Vine Snare", "Healing Bloom"},
            new ItemStack[]{
                new ItemStack(Material.OAK_LOG, 32),
                new ItemStack(Material.GOLDEN_APPLE, 2),
                new ItemStack(Material.EMERALD, 10),
                new ItemStack(Material.DIAMOND, 4),
                new ItemStack(Material.ENCHANTED_BOOK, 1)
            },
            1.0
        ));

        // ============ VOLCANIC TITAN (Tier 2) ============
        bosses.put("Volcanic Titan", new BossData(
            EntityType.MAGMA_CUBE,
            "\u00a76\u00a7l\u26a1 Volcanic Titan \u00a76\u00a7l\u26a1",
            380.0, 38.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 3),
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2)
            },
            new String[]{"Magma Burst", "Eruption", "Molten Slam"},
            new ItemStack[]{
                new ItemStack(Material.MAGMA_BLOCK, 32),
                new ItemStack(Material.BLAZE_ROD, 12),
                new ItemStack(Material.NETHERITE_SCRAP, 4),
                new ItemStack(Material.DIAMOND_BLOCK, 6),
                new ItemStack(Material.FIRE_CHARGE, 16)
            },
            1.0
        ));

        // ============ STORM WYVERN (Tier 2) ============
        bosses.put("Storm Wyvern", new BossData(
            EntityType.PHANTOM,
            "\u00a7b\u00a7l\u26a1 Storm Wyvern \u00a7b\u00a7l\u26a1",
            350.0, 35.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 3),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 1),
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2)
            },
            new String[]{"Lightning Dive", "Thunderclap", "Wind Gust"},
            new ItemStack[]{
                new ItemStack(Material.FEATHER, 32),
                new ItemStack(Material.TRIDENT, 1),
                new ItemStack(Material.DIAMOND, 8),
                new ItemStack(Material.ENCHANTED_BOOK, 2),
                new ItemStack(Material.LIGHTNING_ROD, 1)
            },
            1.0
        ));

        // ============ VOID SOVEREIGN (Tier 3 - Final Boss) ============
        bosses.put("Void Sovereign", new BossData(
            EntityType.WITHER,
            "\u00a78\u00a7l\u2620 THE VOID SOVEREIGN \u00a78\u00a7l\u2620",
            800.0, 60.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 3),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 3),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 4),
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0)
            },
            new String[]{"Reality Collapse", "Void Nova", "Soul Drain", "Phase Shift", "Summon Voidlings"},
            new ItemStack[]{
                new ItemStack(Material.NETHER_STAR, 3),
                new ItemStack(Material.NETHERITE_INGOT, 20),
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 5),
                new ItemStack(Material.BEACON, 1),
                new ItemStack(Material.ELYTRA, 1),
                new ItemStack(Material.DRAGON_HEAD, 1)
            },
            1.0
        ));

        // ============ ANCIENT LICH (Dungeon-locked) ============
        bosses.put("Ancient Lich", new BossData(
            EntityType.WITHER_SKELETON,
            "\u00a75\u00a7l\u2620 Ancient Lich \u00a75\u00a7l\u2620",
            300.0, 32.0, true,
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_SWORD),
                new ItemStack(Material.NETHERITE_HELMET)
            },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 2)
            },
            new String[]{"Necrotic Wave", "Bone Spear Barrage", "Summon Skeletons"},
            new ItemStack[]{
                new ItemStack(Material.WITHER_SKELETON_SKULL, 2),
                new ItemStack(Material.NETHERITE_INGOT, 10),
                new ItemStack(Material.DIAMOND_BLOCK, 6),
                new ItemStack(Material.ENCHANTED_BOOK, 3),
                new ItemStack(Material.TOTEM_OF_UNDYING, 1)
            },
            1.0
        ));

        // ============ CRYSTAL COLOSSUS (Special) ============
        bosses.put("Crystal Colossus", new BossData(
            EntityType.IRON_GOLEM,
            "\u00a7d\u00a7l\u25c8 Crystal Colossus \u00a7d\u00a7l\u25c8",
            450.0, 40.0, true,
            new ItemStack[]{
                new ItemStack(Material.DIAMOND_SWORD),
                new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_HELMET),
                new ItemStack(Material.DIAMOND_LEGGINGS),
                new ItemStack(Material.DIAMOND_BOOTS)
            },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 3),
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2),
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0)
            },
            new String[]{"Crystal Barrage", "Refraction Shield", "Prism Beam"},
            new ItemStack[]{
                new ItemStack(Material.AMETHYST_BLOCK, 32),
                new ItemStack(Material.DIAMOND_BLOCK, 10),
                new ItemStack(Material.ECHO_SHARD, 12),
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 4),
                new ItemStack(Material.NETHERITE_INGOT, 8)
            },
            1.0
        ));

        // ============ SEA LEVIATHAN ============
        bosses.put("Sea Leviathan", new BossData(
            EntityType.GUARDIAN,
            "\u00a7b\u00a7l\u2248 Sea Leviathan \u00a7b\u00a7l\u2248",
            420.0, 38.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.WATER_BREATHING, 999999, 0),
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 2)
            },
            new String[]{"Whirlpool", "Tidal Crush", "Pressure Wave"},
            new ItemStack[]{
                new ItemStack(Material.HEART_OF_THE_SEA, 1),
                new ItemStack(Material.TRIDENT, 1),
                new ItemStack(Material.PRISMARINE_CRYSTALS, 16),
                new ItemStack(Material.NAUTILUS_SHELL, 4),
                new ItemStack(Material.DIAMOND, 10)
            },
            1.0
        ));

        // ============ PLAGUE DOCTOR KING ============
        bosses.put("Plague Doctor King", new BossData(
            EntityType.WITCH,
            "\u00a72\u00a7l\u2620 Plague Doctor King \u00a72\u00a7l\u2620",
            340.0, 30.0, true,
            new ItemStack[]{ new ItemStack(Material.LEATHER_CHESTPLATE) },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2),
                new PotionEffect(PotionEffectType.SPEED, 999999, 1)
            },
            new String[]{"Plague Cloud", "Wither Touch", "Summon Plague Rats"},
            new ItemStack[]{
                new ItemStack(Material.SPIDER_EYE, 16),
                new ItemStack(Material.FERMENTED_SPIDER_EYE, 8),
                new ItemStack(Material.DIAMOND, 8),
                new ItemStack(Material.ENCHANTED_BOOK, 2),
                new ItemStack(Material.GOLDEN_APPLE, 3)
            },
            1.0
        ));

        // ============ INFERNAL CHIMERA ============
        bosses.put("Infernal Chimera", new BossData(
            EntityType.HOGLIN,
            "\u00a7c\u00a7l\u2604 Infernal Chimera \u00a7c\u00a7l\u2604",
            400.0, 42.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 3),
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 2)
            },
            new String[]{"Triple Breath", "Charge Smash", "Fire Roar"},
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_SCRAP, 6),
                new ItemStack(Material.GHAST_TEAR, 8),
                new ItemStack(Material.DIAMOND_BLOCK, 6),
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 3),
                new ItemStack(Material.NETHER_STAR, 1)
            },
            1.0
        ));

        // ============ ANCIENT GOLEM KING ============
        bosses.put("Ancient Golem King", new BossData(
            EntityType.IRON_GOLEM,
            "\u00a77\u00a7l\u2693 Ancient Golem King \u00a77\u00a7l\u2693",
            500.0, 45.0, true,
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_AXE),
                new ItemStack(Material.IRON_CHESTPLATE),
                new ItemStack(Material.IRON_HELMET)
            },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 4),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 3)
            },
            new String[]{"Armor Break Phase", "Ground Pound", "Iron Storm"},
            new ItemStack[]{
                new ItemStack(Material.IRON_BLOCK, 32),
                new ItemStack(Material.NETHERITE_INGOT, 10),
                new ItemStack(Material.DIAMOND_BLOCK, 8),
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 3),
                new ItemStack(Material.BELL, 1)
            },
            1.0
        ));

        // ============ SHADOW DOPPELGANGER ============
        bosses.put("Shadow Doppelganger", new BossData(
            EntityType.VINDICATOR,
            "\u00a78\u00a7l\u25cf Shadow Doppelganger \u00a78\u00a7l\u25cf",
            320.0, 34.0, true,
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_SWORD),
                new ItemStack(Material.NETHERITE_CHESTPLATE)
            },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 2),
                new PotionEffect(PotionEffectType.INVISIBILITY, 999999, 0),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 2)
            },
            new String[]{"Mirror Strike", "Shadow Clone", "Copy Loadout"},
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_INGOT, 8),
                new ItemStack(Material.OBSIDIAN, 32),
                new ItemStack(Material.DIAMOND, 12),
                new ItemStack(Material.ENCHANTED_BOOK, 3),
                new ItemStack(Material.ENDER_PEARL, 16)
            },
            1.0
        ));

        // ============ CELESTIAL DRAGON ============
        bosses.put("Celestial Dragon", new BossData(
            EntityType.ENDER_DRAGON,
            "\u00a7e\u00a7l\u2606 Celestial Dragon \u00a7e\u00a7l\u2606",
            500.0, 48.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 3),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 3),
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0)
            },
            new String[]{"Meteor Dive", "Star Beam", "Celestial Storm"},
            new ItemStack[]{
                new ItemStack(Material.NETHER_STAR, 2),
                new ItemStack(Material.ELYTRA, 1),
                new ItemStack(Material.DRAGON_HEAD, 1),
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 4),
                new ItemStack(Material.DIAMOND_BLOCK, 10)
            },
            1.0
        ));

        // ============ THE CORRUPTED (Secret Final Boss) ============
        bosses.put("The Corrupted", new BossData(
            EntityType.WARDEN,
            "\u00a74\u00a7l\u2620\u2620\u2620 THE CORRUPTED \u2620\u2620\u2620\u00a74\u00a7l",
            1000.0, 70.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 4),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 4),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 5),
                new PotionEffect(PotionEffectType.SPEED, 999999, 1)
            },
            new String[]{"World Corruption", "Total Annihilation", "Reality Tear", "Endless Hunger"},
            new ItemStack[]{
                new ItemStack(Material.NETHER_STAR, 5),
                new ItemStack(Material.NETHERITE_BLOCK, 5),
                new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 10),
                new ItemStack(Material.BEACON, 2),
                new ItemStack(Material.ELYTRA, 1),
                new ItemStack(Material.DRAGON_EGG, 1)
            },
            1.0
        ));
    }
}
