package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class PoppyFields extends BiomeBase {

    public PoppyFields() {
        super("poppy_fields", "Poppy Fields", "\u00a7c\u00a7l\u273f", ChatColor.RED);
        this.climate = "Plains";
        this.description = "Red poppy ocean with wind waves and rare opium lore";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BEE, EntityType.RABBIT, EntityType.CHICKEN);
        this.structureId = "windmill";
        this.guardianMob = "Field Guardian";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Red grass, poppy flowers everywhere
    }

    @Override
    public void generateTrees(int x, int z) {
        // Rare small trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ores
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Field Guardian, bees, rabbits
    }
}
