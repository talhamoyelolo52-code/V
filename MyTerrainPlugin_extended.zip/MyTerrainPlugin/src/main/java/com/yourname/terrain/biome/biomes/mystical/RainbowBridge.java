package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class RainbowBridge extends BiomeBase {

    public RainbowBridge() {
        super("rainbow_bridge", "Rainbow Bridge", "\u00a7c\u00a7l\u2605", ChatColor.RED);
        this.climate = "Sky";
        this.description = "Prismatic terrain, speed boost, and sky temple";
        this.rarity = "Very Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.ALLAY, EntityType.PARROT, EntityType.PHANTOM);
        this.structureId = "sky_temple";
        this.guardianMob = "Bridge Guardian";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Rainbow blocks, cloud
    }

    @Override
    public void generateTrees(int x, int z) {
        // Rainbow "trees"
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, emeralds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Bridge Guardian (Iron Golem), allays, parrots
    }
}
