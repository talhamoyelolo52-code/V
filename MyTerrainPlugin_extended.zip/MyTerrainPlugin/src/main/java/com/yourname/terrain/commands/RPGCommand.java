package com.yourname.terrain.commands;

import com.yourname.terrain.MyTerrainPlugin;
import com.yourname.terrain.rpg.PlayerRPGData;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RPGCommand implements CommandExecutor {

    private final MyTerrainPlugin plugin;

    public RPGCommand(MyTerrainPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command!");
            return true;
        }

        PlayerRPGData data = plugin.getRpgManager().getData(player);

        if (args.length == 0) {
            sender.sendMessage(ChatColor.GOLD + "==== RPG Profile ====");
            sender.sendMessage(ChatColor.YELLOW + "Reputation: " + ChatColor.WHITE + data.getReputation()
                + " (" + data.getReputationRank() + ChatColor.WHITE + ")");
            sender.sendMessage(ChatColor.YELLOW + "Biomes Discovered: " + ChatColor.WHITE + data.getBiomeCount());
            sender.sendMessage(ChatColor.YELLOW + "Boss Souls: " + ChatColor.WHITE + data.getBossSouls().size());
            sender.sendMessage(ChatColor.YELLOW + "Relics: " + ChatColor.WHITE + data.getRelics().size());
            sender.sendMessage(ChatColor.YELLOW + "Titles: " + ChatColor.WHITE
                + (data.getTitles().isEmpty() ? "None" : String.join(", ", data.getTitles())));
            if (data.getActiveProphecy() != null) {
                sender.sendMessage(ChatColor.LIGHT_PURPLE + "Active Prophecy: " + ChatColor.WHITE + data.getActiveProphecy());
            }
            sender.sendMessage(ChatColor.GRAY + "Use /rpg bounty, /rpg prophecy, /rpg relics for more info.");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "bounty" -> {
                if (data.getActiveBounties().isEmpty()) {
                    plugin.getRpgManager().generateBounty(player);
                } else {
                    sender.sendMessage(ChatColor.GOLD + "==== Active Bounties ====");
                    for (PlayerRPGData.Bounty b : data.getActiveBounties()) {
                        sender.sendMessage(ChatColor.YELLOW + "Kill " + b.amountKilled + "/" + b.amountRequired
                            + " " + b.targetMob + ChatColor.GRAY + " -> " + b.rewardReputation + " reputation");
                    }
                }
            }
            case "prophecy" -> plugin.getRpgManager().assignProphecy(player);
            case "relics" -> {
                sender.sendMessage(ChatColor.GOLD + "==== Your Relics ====");
                if (data.getRelics().isEmpty()) {
                    sender.sendMessage(ChatColor.GRAY + "You haven't found any relics yet.");
                } else {
                    for (String relic : data.getRelics()) {
                        sender.sendMessage(ChatColor.AQUA + "- " + relic);
                    }
                }
            }
            case "biomes" -> {
                sender.sendMessage(ChatColor.GOLD + "==== Biome Mastery ====");
                int total = plugin.getBiomeManager().getAllBiomes().size();
                sender.sendMessage(ChatColor.YELLOW + "Discovered: " + ChatColor.WHITE
                    + data.getBiomeCount() + "/" + total);
            }
            default -> sender.sendMessage(ChatColor.RED + "Usage: /rpg [bounty|prophecy|relics|biomes]");
        }

        return true;
    }
}
