package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class SunflowerPlains extends BiomeBase {

    public SunflowerPlains() {
        super("sunflower_plains", "Sunflower Plains", "\u00a7e\u00a7l\u2600", ChatColor.YELLOW);
        this.climate = "Plains";
        this.description = "Giant sunflower fields stretching to the horizon";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.BEE, EntityType.RABBIT, EntityType.CHICKEN);
        this.structureId = "farmhouse";
        this.guardianMob = "Scarecrow";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Golden grass, sunflower blocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // Rare oak trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Standard ore distribution
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Bees, rabbits, chickens
    }
}
