package com.yourname.terrain.biome.biomes.seasonal;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class WinterWonderland extends BiomeBase {

    public WinterWonderland() {
        super("winter_wonderland", "Winter Wonderland", "\u00a7b\u00a7l\u2744", ChatColor.AQUA);
        this.climate = "Winter";
        this.description = "Snow everywhere, igloos, reindeer, and northern lights";
        this.rarity = "Common";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.POLAR_BEAR, EntityType.STRAY, EntityType.SNOW_GOLEM);
        this.structureId = "ice_palace";
        this.guardianMob = "Ice Queen";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Snow, ice, igloos
    }

    @Override
    public void generateTrees(int x, int z) {
        // Snow-covered trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Ice Queen (Stray boss), polar bears, snow golems
    }
}
