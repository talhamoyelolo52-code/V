package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class TimelessGarden extends BiomeBase {

    public TimelessGarden() {
        super("timeless_garden", "Timeless Garden", "\u00a7a\u00a7l\u2698", ChatColor.GREEN);
        this.climate = "Magic";
        this.description = "Flowers never wilt, eternal day, and fairies";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.ALLAY, EntityType.BEE, EntityType.RABBIT);
        this.structureId = "eternal_fountain";
        this.guardianMob = "Time Keeper";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Eternal grass, flowers
    }

    @Override
    public void generateTrees(int x, int z) {
        // Eternal trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, emeralds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Time Keeper (Wandering Trader), allays, bees
    }
}
