package com.yourname.terrain.biome.biomes.mystical;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class RainbowHills extends BiomeBase {

    public RainbowHills() {
        super("rainbow_hills", "Rainbow Hills", "\u00a7c\u00a7l\u2605", ChatColor.RED);
        this.climate = "Colorful";
        this.description = "Prismatic terrain, walking gives speed boost";
        this.rarity = "Rare";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_WARPED_FOREST_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.ALLAY, EntityType.PARROT, EntityType.RABBIT);
        this.structureId = "prism_cave";
        this.guardianMob = "Rainbow Sprite";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Rainbow wool, colorful grass
    }

    @Override
    public void generateTrees(int x, int z) {
        // Rainbow trees
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, emeralds
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Rainbow Sprite (Allay), parrots, rabbits
    }
}
