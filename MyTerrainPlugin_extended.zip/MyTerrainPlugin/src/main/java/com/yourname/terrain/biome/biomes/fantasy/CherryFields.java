package com.yourname.terrain.biome.biomes.fantasy;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class CherryFields extends BiomeBase {

    public CherryFields() {
        super("cherry_fields", "Cherry Fields", "\u00a7d\u00a7l\u273f", ChatColor.LIGHT_PURPLE);
        this.climate = "Temperate";
        this.description = "Peaceful fields of cherry blossoms and zen gardens";
        this.rarity = "Common";
        this.difficulty = "Easy";
        this.enterSound = Sound.AMBIENT_BASALT_DELTAS_ADDITIONS;
        this.nativeMobs = Arrays.asList(EntityType.BEE, EntityType.RABBIT, EntityType.CHICKEN);
        this.structureId = "zen_temple";
        this.guardianMob = "Cherry Spirit";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Pink grass, white sand, stone paths
    }

    @Override
    public void generateTrees(int x, int z) {
        // Cherry blossom trees with pink leaves, falling petals
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra gold, quartz
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Cherry Spirit (Allay), bees, rabbits
    }
}
