package com.yourname.terrain.biome.biomes.dangerous;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class BoneYard extends BiomeBase {

    public BoneYard() {
        super("bone_yard", "Bone Yard", "\u00a7f\u00a7l\u2620", ChatColor.WHITE);
        this.climate = "Death";
        this.description = "Giant skeletons of ancient beasts and vultures";
        this.rarity = "Rare";
        this.difficulty = "Hard";
        this.enterSound = Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD;
        this.nativeMobs = Arrays.asList(EntityType.SKELETON, EntityType.STRAY, EntityType.WITHER_SKELETON);
        this.structureId = "fossil_site";
        this.guardianMob = "Bone Dragon";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Bone blocks, sand
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant bone structures
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra bone meal, coal
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Bone Dragon (Ender Dragon mini), skeletons, strays
    }
}
