package com.yourname.terrain.biome.biomes.landform;

import com.yourname.terrain.biome.BiomeBase;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;

import java.util.Arrays;

public class GiantMushroomJungle extends BiomeBase {

    public GiantMushroomJungle() {
        super("giant_mushroom_jungle", "Giant Mushroom Jungle", "\u00a7d\u00a7l\u25c6", ChatColor.LIGHT_PURPLE);
        this.climate = "Fungi";
        this.description = "30+ block tall mushrooms with glowing spores and mycelium caves";
        this.rarity = "Rare";
        this.difficulty = "Medium";
        this.enterSound = Sound.AMBIENT_CAVE;
        this.nativeMobs = Arrays.asList(EntityType.MOOSHROOM, EntityType.SLIME, EntityType.BAT);
        this.structureId = "mushroom_house";
        this.guardianMob = "Spore Lord";
    }

    @Override
    public void generateSurface(int x, int z) {
        // Mycelium, mushroom blocks
    }

    @Override
    public void generateTrees(int x, int z) {
        // Giant mushrooms 30+ blocks
    }

    @Override
    public void generateOres(int x, int z) {
        // Extra coal, iron
    }

    @Override
    public void spawnMobs(int x, int z) {
        // Spore Lord (Mooshroom), slimes, bats
    }
}
