package com.yourname.terrain.mobs;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;

/**
 * Additional custom mobs: ecosystem creatures, fruit grove guardians,
 * pack-hunters, alpha variants and rideable/tameable companions.
 * Called from CustomMobManager constructor.
 */
public class ExtraMobs {

    public static void register(Map<String, MobData> mobs) {

        // ============ FRUIT GROVE / ECOSYSTEM MOBS ============
        mobs.put("Mango Grove Keeper", new MobData(
            EntityType.IRON_GOLEM,
            "\u00a76Mango Grove Keeper",
            70.0, 10.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 1)
            }
        ));

        mobs.put("Glowberry Sprite", new MobData(
            EntityType.ALLAY,
            "\u00a7eGlowberry Sprite",
            18.0, 0.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0),
                new PotionEffect(PotionEffectType.SPEED, 999999, 1)
            }
        ));

        mobs.put("Dragonfruit Stalker", new MobData(
            EntityType.OCELOT,
            "\u00a7dDragonfruit Stalker",
            35.0, 8.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 2),
                new PotionEffect(PotionEffectType.JUMP_BOOST, 999999, 1)
            }
        ));

        mobs.put("Coconut Crab", new MobData(
            EntityType.SILVERFISH,
            "\u00a76Coconut Crab",
            25.0, 6.0, true,
            new ItemStack[]{new ItemStack(Material.TURTLE_HELMET)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 1)
            }
        ));

        // ============ PACK AI / TERRITORIAL MOBS ============
        mobs.put("Shadow Wolf", new MobData(
            EntityType.WOLF,
            "\u00a78Shadow Wolf",
            30.0, 9.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 2),
                new PotionEffect(PotionEffectType.INVISIBILITY, 200, 0)
            }
        ));

        mobs.put("Ash Zombie", new MobData(
            EntityType.ZOMBIE,
            "\u00a78Ash Zombie",
            35.0, 7.0, true,
            new ItemStack[]{new ItemStack(Material.NETHERITE_HELMET)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0)
            }
        ));

        mobs.put("Crystal Spider", new MobData(
            EntityType.CAVE_SPIDER,
            "\u00a7bCrystal Spider",
            22.0, 6.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 1),
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0)
            }
        ));

        mobs.put("Void Crawler", new MobData(
            EntityType.ENDERMITE,
            "\u00a78Void Crawler",
            28.0, 7.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0),
                new PotionEffect(PotionEffectType.SPEED, 999999, 1)
            }
        ));

        mobs.put("Bone Archer", new MobData(
            EntityType.SKELETON,
            "\u00a7fBone Archer",
            30.0, 8.0, true,
            new ItemStack[]{new ItemStack(Material.BOW)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 0)
            }
        ));

        mobs.put("Plague Bat", new MobData(
            EntityType.BAT,
            "\u00a72Plague Bat",
            12.0, 4.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 2)
            }
        ));

        mobs.put("Magma Slime", new MobData(
            EntityType.MAGMA_CUBE,
            "\u00a76Magma Slime",
            25.0, 7.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0)
            }
        ));

        // ============ NEUTRAL / TAMEABLE ============
        mobs.put("Giant Tortoise", new MobData(
            EntityType.TURTLE,
            "\u00a72Giant Tortoise",
            60.0, 0.0, true,
            new ItemStack[]{new ItemStack(Material.TURTLE_HELMET)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 2),
                new PotionEffect(PotionEffectType.SLOWNESS, 999999, 0)
            }
        ));

        mobs.put("Crystal Deer", new MobData(
            EntityType.GOAT,
            "\u00a7bCrystal Deer",
            22.0, 0.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0),
                new PotionEffect(PotionEffectType.SPEED, 999999, 1)
            }
        ));

        mobs.put("Lava Turtle", new MobData(
            EntityType.TURTLE,
            "\u00a76Lava Turtle",
            40.0, 0.0, true,
            new ItemStack[]{new ItemStack(Material.GOLDEN_HELMET)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 1)
            }
        ));

        // ============ MIMIC / SPECIAL ============
        mobs.put("Mimic Chest", new MobData(
            EntityType.VEX,
            "\u00a7eMimic Chest",
            35.0, 12.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.INVISIBILITY, 999999, 0),
                new PotionEffect(PotionEffectType.SPEED, 999999, 1)
            }
        ));

        mobs.put("Spectral Knight", new MobData(
            EntityType.ZOMBIFIED_PIGLIN,
            "\u00a7fSpectral Knight",
            55.0, 14.0, true,
            new ItemStack[]{
                new ItemStack(Material.IRON_SWORD),
                new ItemStack(Material.IRON_CHESTPLATE),
                new ItemStack(Material.IRON_HELMET)
            },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.INVISIBILITY, 200, 0),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 1)
            }
        ));

        mobs.put("Fungal Creeper", new MobData(
            EntityType.CREEPER,
            "\u00a72Fungal Creeper",
            25.0, 10.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 0)
            }
        ));

        mobs.put("Giant Centipede", new MobData(
            EntityType.SILVERFISH,
            "\u00a72Giant Centipede",
            38.0, 9.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 2)
            }
        ));

        mobs.put("Sandstorm Elemental", new MobData(
            EntityType.HUSK,
            "\u00a7eSandstorm Elemental",
            45.0, 11.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 1),
                new PotionEffect(PotionEffectType.RESISTANCE, 999999, 0)
            }
        ));

        mobs.put("Ice Banshee", new MobData(
            EntityType.STRAY,
            "\u00a7bIce Banshee",
            42.0, 10.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 1),
                new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0)
            }
        ));

        mobs.put("Lava Golem", new MobData(
            EntityType.MAGMA_CUBE,
            "\u00a76Lava Golem",
            65.0, 13.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 1)
            }
        ));

        // ============ ALPHA VARIANTS ============
        mobs.put("Alpha Shadow Wolf", new MobData(
            EntityType.WOLF,
            "\u00a78\u00a7lAlpha Shadow Wolf",
            70.0, 16.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 3),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 1),
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0)
            }
        ));

        mobs.put("Alpha Ash Zombie", new MobData(
            EntityType.ZOMBIE,
            "\u00a78\u00a7lAlpha Ash Zombie",
            80.0, 14.0, true,
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_HELMET),
                new ItemStack(Material.NETHERITE_CHESTPLATE)
            },
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 2),
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0)
            }
        ));

        mobs.put("Alpha Magma Slime", new MobData(
            EntityType.MAGMA_CUBE,
            "\u00a76\u00a7lAlpha Magma Slime",
            60.0, 15.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 999999, 0),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 2),
                new PotionEffect(PotionEffectType.GLOWING, 999999, 0)
            }
        ));

        // ============ NECROMANCER / EVOLUTION ============
        mobs.put("Necromancer", new MobData(
            EntityType.WITHER_SKELETON,
            "\u00a75Necromancer",
            55.0, 11.0, true,
            new ItemStack[]{new ItemStack(Material.STICK)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.REGENERATION, 999999, 1),
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 1)
            }
        ));

        mobs.put("Berserker Brute", new MobData(
            EntityType.VINDICATOR,
            "\u00a7cBerserker Brute",
            65.0, 15.0, true,
            new ItemStack[]{new ItemStack(Material.IRON_AXE)},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.STRENGTH, 999999, 1),
                new PotionEffect(PotionEffectType.SPEED, 999999, 0)
            }
        ));

        // ============ MOUNT / COMPANIONS ============
        mobs.put("Storm Falcon", new MobData(
            EntityType.PARROT,
            "\u00a7bStorm Falcon",
            15.0, 0.0, false,
            new ItemStack[]{},
            new PotionEffect[]{
                new PotionEffect(PotionEffectType.SPEED, 999999, 2)
            }
        ));

        mobs.put("Jungle Parrot Companion", new MobData(
            EntityType.PARROT,
            "\u00a7aJungle Parrot",
            10.0, 0.0, false,
            new ItemStack[]{},
            new PotionEffect[]{}
        ));
    }
}
